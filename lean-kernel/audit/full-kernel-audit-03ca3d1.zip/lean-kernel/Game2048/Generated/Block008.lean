import Game2048.Generated.Checkpoints

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace Game2048.Cert131072

namespace Segment0128
def b0 : Board := c0128
def b1 : Board := ⟨⟨16,8,4,0⟩,⟨16,32,64,128⟩,⟨2048,1024,512,256⟩,⟨4096,8192,16384,32768⟩⟩
def b2 : Board := ⟨⟨4,8,4,0⟩,⟨32,32,64,128⟩,⟨2048,1024,512,256⟩,⟨4096,8192,16384,32768⟩⟩
def b3 : Board := ⟨⟨4,8,4,4⟩,⟨64,64,128,0⟩,⟨2048,1024,512,256⟩,⟨4096,8192,16384,32768⟩⟩
def b4 : Board := ⟨⟨0,4,8,8⟩,⟨0,4,128,128⟩,⟨2048,1024,512,256⟩,⟨4096,8192,16384,32768⟩⟩
def b5 : Board := ⟨⟨0,4,4,16⟩,⟨0,0,4,256⟩,⟨2048,1024,512,256⟩,⟨4096,8192,16384,32768⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨2048,1024,512,512⟩,⟨4096,8192,16384,32768⟩⟩
def b7 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,0⟩,⟨2048,1024,1024,4⟩,⟨4096,8192,16384,32768⟩⟩
def b8 : Board := ⟨⟨0,0,0,4⟩,⟨8,8,16,0⟩,⟨2048,1024,1024,4⟩,⟨4096,8192,16384,32768⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,16,4⟩,⟨2048,1024,1024,8⟩,⟨4096,8192,16384,32768⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨16,16,4,4⟩,⟨2048,2048,8,0⟩,⟨4096,8192,16384,32768⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨32,8,0,0⟩,⟨4096,8,4,0⟩,⟨4096,8192,16384,32768⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,0⟩,⟨8192,8192,16384,32768⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,32,16,4⟩,⟨0,16384,16384,32768⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,32,16,4⟩,⟨4,0,32768,32768⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,32,32768,32768⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨0,4,16,8⟩,⟨0,8,32,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,8,16,8⟩,⟨4,8,32,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨4,16,32,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,16,32,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,8⟩,⟨8,16,32,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,0⟩,⟨8,16,32,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨16,32,32,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,4,8,4⟩,⟨0,16,64,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨4,16,64,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨8,16,64,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨8,16,64,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨8,16,64,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨8,32,64,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨8,32,64,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,8,0,4⟩,⟨16,32,64,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,4,0⟩,⟨16,32,64,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨16,32,64,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,4⟩,⟨16,32,64,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨16,32,64,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨32,32,64,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨32,32,64,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,4,0,0⟩,⟨64,64,65536,0⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,0,4⟩,⟨64,64,65536,0⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨0,0,128,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨4,16,128,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨8,16,128,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,0,0⟩,⟨8,16,128,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,32,128,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,32,128,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,32,128,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨16,32,128,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨16,32,128,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨16,32,128,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,32,128,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,16,8,4⟩,⟨16,32,128,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,16,8,8⟩,⟨16,32,128,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,16⟩,⟨16,32,128,65536⟩⟩
def b53 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨8,32,0,0⟩,⟨16,32,128,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨16,64,128,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨16,64,128,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,0,4⟩,⟨16,64,128,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,64,128,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,8,4,4⟩,⟨32,64,128,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨32,64,128,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨32,64,128,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,128,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨32,64,128,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨32,64,128,65536⟩⟩
def b65 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨32,64,128,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,128,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,128,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,128,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b72 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b73 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b74 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b75 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b78 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b79 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,128,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,128,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,128,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,128,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,16⟩,⟨64,64,128,65536⟩⟩
def b84 : Board := ⟨⟨0,0,4,4⟩,⟨0,0,0,8⟩,⟨32,16,8,16⟩,⟨0,128,128,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨0,16,8,16⟩,⟨32,128,128,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,8⟩,⟨0,16,8,16⟩,⟨4,32,256,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,8⟩,⟨4,16,16,16⟩,⟨4,32,256,65536⟩⟩
def b88 : Board := ⟨⟨4,0,0,4⟩,⟨8,0,0,0⟩,⟨4,32,16,0⟩,⟨4,32,256,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,16,4⟩,⟨8,64,256,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨4,4,16,4⟩,⟨16,64,256,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,4,0⟩,⟨16,64,256,65536⟩⟩
def b92 : Board := ⟨⟨8,0,0,0⟩,⟨0,4,0,0⟩,⟨8,16,4,0⟩,⟨16,64,256,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,4,0⟩,⟨16,16,4,0⟩,⟨16,64,256,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨0,16,8,0⟩,⟨32,64,256,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,256,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,64,256,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,256,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,256,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,256,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b104 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b105 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b106 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b107 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b110 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b111 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,256,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,256,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,256,65536⟩⟩
def b114 : Board := ⟨⟨0,4,0,0⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,256,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨32,16,8,16⟩,⟨64,64,256,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨32,16,8,16⟩,⟨0,128,256,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨0,16,16,16⟩,⟨32,128,256,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨32,16,4,0⟩,⟨32,128,256,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨4,16,4,0⟩,⟨64,128,256,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨8,16,4,0⟩,⟨64,128,256,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨8,16,4,0⟩,⟨64,128,256,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,8,4⟩,⟨64,128,256,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,128,256,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,128,256,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,128,256,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,128,256,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,128,256,65536⟩⟩
def b128 : Board := c0129
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.down, .i3, .i0, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.right, .i1, .i3, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.right, .i0, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
end Segment0128
theorem chunk0128 : Plays c0128 128 c0129 :=
  Segment0128.p128

namespace Segment0129
def b0 : Board := c0129
def b1 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨64,128,256,65536⟩⟩
def b2 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,0,0⟩,⟨64,128,256,65536⟩⟩
def b3 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨64,4,0,0⟩,⟨64,128,256,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨128,128,256,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,4,0,0⟩,⟨256,256,65536,0⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,0,4⟩,⟨256,256,65536,0⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨0,0,512,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨4,16,512,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,0,0⟩,⟨4,16,512,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,32,512,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,32,512,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,32,512,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,32,512,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨16,32,512,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨16,32,512,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨16,32,512,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,32,512,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,16,8,4⟩,⟨16,32,512,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,16,8,8⟩,⟨16,32,512,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,16⟩,⟨16,32,512,65536⟩⟩
def b21 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨8,32,0,0⟩,⟨16,32,512,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨16,64,512,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨16,64,512,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,0,4⟩,⟨16,64,512,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,64,512,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,8,4,4⟩,⟨32,64,512,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨32,64,512,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨32,64,512,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,512,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨32,64,512,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨32,64,512,65536⟩⟩
def b33 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨32,64,512,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,512,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,512,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,512,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b40 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b41 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b42 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b43 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b46 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b47 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,512,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,512,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,512,65536⟩⟩
def b50 : Board := ⟨⟨0,4,0,0⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,512,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨32,16,8,16⟩,⟨64,64,512,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨32,16,8,16⟩,⟨0,128,512,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨0,16,16,16⟩,⟨32,128,512,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨32,16,4,0⟩,⟨32,128,512,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨4,16,4,0⟩,⟨64,128,512,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨8,16,4,0⟩,⟨64,128,512,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨8,16,4,0⟩,⟨64,128,512,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,8,4⟩,⟨64,128,512,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,128,512,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,128,512,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,128,512,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,128,512,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,128,512,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,128,512,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨64,128,512,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,0,0⟩,⟨64,128,512,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨64,4,0,0⟩,⟨64,128,512,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨128,128,512,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,0,16,4⟩,⟨4,256,512,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨4,256,512,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,256,512,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,8⟩,⟨8,256,512,65536⟩⟩
def b73 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,0⟩,⟨8,256,512,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨16,256,512,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,512,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,512,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,8,4,0⟩,⟨32,256,512,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,4,4,0⟩,⟨32,256,512,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,8,4,0⟩,⟨32,256,512,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,256,512,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,256,512,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,256,512,65536⟩⟩
def b83 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,256,512,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,256,512,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,256,512,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,256,512,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,256,512,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,256,512,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,256,512,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,256,512,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,256,512,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,256,512,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,256,512,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,256,512,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,256,512,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,256,512,65536⟩⟩
def b97 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,256,512,65536⟩⟩
def b98 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,256,512,65536⟩⟩
def b99 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,256,512,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,256,512,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,256,512,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,256,512,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,256,512,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b107 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,256,512,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,256,512,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,256,512,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,256,512,65536⟩⟩
def b113 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,256,512,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,256,512,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,256,512,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,256,512,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,256,512,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,256,512,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,256,512,65536⟩⟩
def b121 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,256,512,65536⟩⟩
def b122 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,256,512,65536⟩⟩
def b123 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,256,512,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,256,512,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,256,512,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,256,512,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,256,512,65536⟩⟩
def b128 : Board := c0130
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.right, .i1, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
end Segment0129
theorem chunk0129 : Plays c0129 128 c0130 :=
  Segment0129.p128

namespace Segment0130
def b0 : Board := c0130
def b1 : Board := ⟨⟨0,0,4,0⟩,⟨8,0,0,0⟩,⟨64,32,32,0⟩,⟨128,256,512,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨64,32,32,0⟩,⟨128,256,512,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨64,64,4,0⟩,⟨128,256,512,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,0,0⟩,⟨128,4,0,0⟩,⟨128,256,512,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,256,512,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨0,512,512,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨0,0,1024,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨4,16,1024,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,0,0⟩,⟨4,16,1024,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,32,1024,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,32,1024,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,32,1024,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,32,1024,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨16,32,1024,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨16,32,1024,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨16,32,1024,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,32,1024,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,16,8,4⟩,⟨16,32,1024,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,16,8,8⟩,⟨16,32,1024,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,16⟩,⟨16,32,1024,65536⟩⟩
def b21 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨8,32,0,0⟩,⟨16,32,1024,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨16,64,1024,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨16,64,1024,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,0,4⟩,⟨16,64,1024,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,64,1024,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,8,4,4⟩,⟨32,64,1024,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨32,64,1024,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨32,64,1024,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,1024,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨32,64,1024,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨32,64,1024,65536⟩⟩
def b33 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨32,64,1024,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,1024,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,1024,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,1024,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b40 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b41 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b42 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b43 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b46 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b47 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,1024,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,1024,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,1024,65536⟩⟩
def b50 : Board := ⟨⟨0,4,0,0⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,1024,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨32,16,8,16⟩,⟨64,64,1024,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨32,16,8,16⟩,⟨0,128,1024,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨0,16,16,16⟩,⟨32,128,1024,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨32,16,4,0⟩,⟨32,128,1024,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨4,16,4,0⟩,⟨64,128,1024,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨8,16,4,0⟩,⟨64,128,1024,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨8,16,4,0⟩,⟨64,128,1024,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,8,4⟩,⟨64,128,1024,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,128,1024,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,128,1024,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,128,1024,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,128,1024,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,128,1024,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,128,1024,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨64,128,1024,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,0,0⟩,⟨64,128,1024,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨64,4,0,0⟩,⟨64,128,1024,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨128,128,1024,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,0,16,4⟩,⟨4,256,1024,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨4,256,1024,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,256,1024,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,8⟩,⟨8,256,1024,65536⟩⟩
def b73 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,0⟩,⟨8,256,1024,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨16,256,1024,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,1024,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,1024,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,8,4,0⟩,⟨32,256,1024,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,4,4,0⟩,⟨32,256,1024,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,8,4,0⟩,⟨32,256,1024,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,256,1024,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,256,1024,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,256,1024,65536⟩⟩
def b83 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,256,1024,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,256,1024,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,256,1024,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,256,1024,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,256,1024,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,256,1024,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,256,1024,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,256,1024,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,256,1024,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,256,1024,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,256,1024,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,256,1024,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,256,1024,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,256,1024,65536⟩⟩
def b97 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,256,1024,65536⟩⟩
def b98 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,256,1024,65536⟩⟩
def b99 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,256,1024,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,256,1024,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,256,1024,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,256,1024,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,256,1024,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b107 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,256,1024,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,256,1024,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,256,1024,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,256,1024,65536⟩⟩
def b113 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,256,1024,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,256,1024,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,256,1024,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,256,1024,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,256,1024,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,256,1024,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,256,1024,65536⟩⟩
def b121 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,256,1024,65536⟩⟩
def b122 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,256,1024,65536⟩⟩
def b123 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,256,1024,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,256,1024,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,256,1024,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,256,1024,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,256,1024,65536⟩⟩
def b128 : Board := c0131
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.right, .i1, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
end Segment0130
theorem chunk0130 : Plays c0130 128 c0131 :=
  Segment0130.p128

namespace Segment0131
def b0 : Board := c0131
def b1 : Board := ⟨⟨0,0,4,0⟩,⟨8,0,0,0⟩,⟨64,32,32,0⟩,⟨128,256,1024,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨64,32,32,0⟩,⟨128,256,1024,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨64,64,4,0⟩,⟨128,256,1024,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,0,0⟩,⟨128,4,0,0⟩,⟨128,256,1024,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,256,1024,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,16,8,4⟩,⟨4,512,1024,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨4,512,1024,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨4,512,1024,65536⟩⟩
def b9 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,8,4⟩,⟨4,512,1024,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,4⟩,⟨8,512,1024,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨0,16,8,8⟩,⟨16,512,1024,65536⟩⟩
def b12 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,0,0⟩,⟨16,512,1024,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,16,0,0⟩,⟨32,512,1024,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,0,8,16⟩,⟨32,512,1024,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,16,0,0⟩,⟨32,512,1024,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,4,0⟩,⟨32,512,1024,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,4,0,4⟩,⟨32,512,1024,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,512,1024,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨64,512,1024,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,512,1024,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,512,1024,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,512,1024,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,512,1024,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,512,1024,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,512,1024,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,512,1024,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,512,1024,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,512,1024,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,512,1024,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,512,1024,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,512,1024,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,512,1024,65536⟩⟩
def b33 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,512,1024,65536⟩⟩
def b34 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,512,1024,65536⟩⟩
def b35 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,512,1024,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,512,1024,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,512,1024,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,512,1024,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,512,1024,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,512,1024,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,512,1024,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,512,1024,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,512,1024,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,512,1024,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,512,1024,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,512,1024,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,512,1024,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,512,1024,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,512,1024,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,512,1024,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,512,1024,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,512,1024,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,512,1024,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,512,1024,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,512,1024,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,512,1024,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,512,1024,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,512,1024,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,512,1024,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,512,1024,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,512,1024,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,512,1024,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,512,1024,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,512,1024,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,512,1024,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,512,1024,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,512,1024,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,512,1024,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,512,1024,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,512,1024,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,512,1024,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,512,1024,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,512,1024,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,512,1024,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,512,1024,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,512,1024,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,512,1024,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,512,1024,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,512,1024,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,512,1024,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,512,1024,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,512,1024,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,512,1024,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,512,1024,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,512,1024,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,512,1024,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,512,1024,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,512,1024,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,512,1024,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,512,1024,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,512,1024,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,512,1024,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,512,1024,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,512,1024,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,512,1024,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,512,1024,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,512,1024,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,512,1024,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,512,1024,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,512,1024,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,512,1024,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,512,1024,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,512,1024,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,512,1024,65536⟩⟩
def b128 : Board := c0132
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0131
theorem chunk0131 : Plays c0131 128 c0132 :=
  Segment0131.p128

namespace Segment0132
def b0 : Board := c0132
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,512,1024,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨256,512,1024,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨256,512,1024,65536⟩⟩
def b4 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,0⟩,⟨256,512,1024,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨128,128,8,4⟩,⟨256,512,1024,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨16,0,0,0⟩,⟨256,8,4,0⟩,⟨256,512,1024,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨512,512,1024,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,8,8,0⟩,⟨1024,1024,65536,0⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,4,0⟩,⟨16,8,8,4⟩,⟨1024,1024,65536,0⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,16,16,4⟩,⟨0,0,2048,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,0,16,4⟩,⟨4,16,2048,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨4,16,4,0⟩,⟨4,16,2048,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,4,0⟩,⟨8,32,2048,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,4,4,0⟩,⟨16,32,2048,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,4,0⟩,⟨16,32,2048,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨16,32,2048,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,4⟩,⟨16,32,2048,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨16,32,2048,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨16,32,2048,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨4,16,8,8⟩,⟨16,32,2048,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨4,4,16,16⟩,⟨16,32,2048,65536⟩⟩
def b22 : Board := ⟨⟨4,0,4,0⟩,⟨0,0,0,0⟩,⟨8,32,0,0⟩,⟨16,32,2048,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,4,0⟩,⟨16,64,2048,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨16,64,2048,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,4⟩,⟨16,64,2048,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨16,64,2048,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨32,64,2048,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨32,64,2048,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨32,64,2048,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,2048,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,64,2048,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,2048,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,2048,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,2048,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b40 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b41 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b42 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b43 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b46 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b47 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,2048,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,2048,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,2048,65536⟩⟩
def b50 : Board := ⟨⟨0,4,0,0⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,2048,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨32,16,8,16⟩,⟨64,64,2048,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨32,16,8,16⟩,⟨0,128,2048,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨0,16,16,16⟩,⟨32,128,2048,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨32,16,4,0⟩,⟨32,128,2048,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨4,16,4,0⟩,⟨64,128,2048,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨8,16,4,0⟩,⟨64,128,2048,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨8,16,4,0⟩,⟨64,128,2048,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,8,4⟩,⟨64,128,2048,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,128,2048,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,128,2048,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,128,2048,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,128,2048,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,128,2048,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,128,2048,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨64,128,2048,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,0,0⟩,⟨64,128,2048,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨64,4,0,0⟩,⟨64,128,2048,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨128,128,2048,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,0,16,4⟩,⟨4,256,2048,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨4,256,2048,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,256,2048,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,8⟩,⟨8,256,2048,65536⟩⟩
def b73 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,0⟩,⟨8,256,2048,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨16,256,2048,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,2048,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,2048,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,8,4,0⟩,⟨32,256,2048,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,4,4,0⟩,⟨32,256,2048,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,8,4,0⟩,⟨32,256,2048,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,256,2048,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,256,2048,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,256,2048,65536⟩⟩
def b83 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,256,2048,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,256,2048,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,256,2048,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,256,2048,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,256,2048,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,256,2048,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,256,2048,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,256,2048,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,256,2048,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,256,2048,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,256,2048,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,256,2048,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,256,2048,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,256,2048,65536⟩⟩
def b97 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,256,2048,65536⟩⟩
def b98 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,256,2048,65536⟩⟩
def b99 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,256,2048,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,256,2048,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,256,2048,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,256,2048,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,256,2048,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b107 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,256,2048,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,256,2048,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,256,2048,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,256,2048,65536⟩⟩
def b113 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,256,2048,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,256,2048,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,256,2048,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,256,2048,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,256,2048,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,256,2048,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,256,2048,65536⟩⟩
def b121 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,256,2048,65536⟩⟩
def b122 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,256,2048,65536⟩⟩
def b123 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,256,2048,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,256,2048,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,256,2048,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,256,2048,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,256,2048,65536⟩⟩
def b128 : Board := c0133
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
end Segment0132
theorem chunk0132 : Plays c0132 128 c0133 :=
  Segment0132.p128

namespace Segment0133
def b0 : Board := c0133
def b1 : Board := ⟨⟨0,0,4,0⟩,⟨8,0,0,0⟩,⟨64,32,32,0⟩,⟨128,256,2048,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨64,32,32,0⟩,⟨128,256,2048,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨64,64,4,0⟩,⟨128,256,2048,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,0,0⟩,⟨128,4,0,0⟩,⟨128,256,2048,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,256,2048,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,16,8,4⟩,⟨4,512,2048,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨4,512,2048,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨4,512,2048,65536⟩⟩
def b9 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,8,4⟩,⟨4,512,2048,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,4⟩,⟨8,512,2048,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨0,16,8,8⟩,⟨16,512,2048,65536⟩⟩
def b12 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,0,0⟩,⟨16,512,2048,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,16,0,0⟩,⟨32,512,2048,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,0,8,16⟩,⟨32,512,2048,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,16,0,0⟩,⟨32,512,2048,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,4,0⟩,⟨32,512,2048,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,4,0,4⟩,⟨32,512,2048,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,512,2048,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨64,512,2048,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,512,2048,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,512,2048,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,512,2048,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,512,2048,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,512,2048,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,512,2048,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,512,2048,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,512,2048,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,512,2048,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,512,2048,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,512,2048,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,512,2048,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,512,2048,65536⟩⟩
def b33 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,512,2048,65536⟩⟩
def b34 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,512,2048,65536⟩⟩
def b35 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,512,2048,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,512,2048,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,512,2048,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,512,2048,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,512,2048,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,512,2048,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,512,2048,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,512,2048,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,512,2048,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,512,2048,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,512,2048,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,512,2048,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,512,2048,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,512,2048,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,512,2048,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,512,2048,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,512,2048,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,512,2048,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,512,2048,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,512,2048,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,512,2048,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,512,2048,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,512,2048,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,512,2048,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,512,2048,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,512,2048,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,512,2048,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,512,2048,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,512,2048,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,512,2048,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,512,2048,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,512,2048,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,512,2048,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,512,2048,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,512,2048,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,512,2048,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,512,2048,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,512,2048,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,512,2048,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,512,2048,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,512,2048,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,512,2048,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,512,2048,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,512,2048,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,512,2048,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,512,2048,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,512,2048,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,512,2048,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,512,2048,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,512,2048,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,512,2048,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,512,2048,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,512,2048,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,512,2048,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,512,2048,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,512,2048,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,512,2048,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,512,2048,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,512,2048,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,512,2048,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,512,2048,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,512,2048,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,512,2048,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,512,2048,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,512,2048,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,512,2048,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,512,2048,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,512,2048,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,512,2048,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,512,2048,65536⟩⟩
def b128 : Board := c0134
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0133
theorem chunk0133 : Plays c0133 128 c0134 :=
  Segment0133.p128

namespace Segment0134
def b0 : Board := c0134
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,512,2048,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨256,512,2048,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨256,512,2048,65536⟩⟩
def b4 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,0⟩,⟨256,512,2048,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨128,128,8,4⟩,⟨256,512,2048,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨16,0,0,0⟩,⟨256,8,4,0⟩,⟨256,512,2048,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨512,512,2048,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,16,8,8⟩,⟨4,1024,2048,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,0,16,16⟩,⟨4,1024,2048,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,0,16,16⟩,⟨8,1024,2048,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,0,4,32⟩,⟨8,1024,2048,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,4,4,32⟩,⟨8,1024,2048,65536⟩⟩
def b13 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,32,0⟩,⟨8,1024,2048,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,32,0⟩,⟨16,1024,2048,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,8,4,32⟩,⟨16,1024,2048,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,4,32,0⟩,⟨16,1024,2048,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,32,0⟩,⟨16,1024,2048,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,32,0⟩,⟨32,1024,2048,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,32,0⟩,⟨32,1024,2048,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,32,0,0⟩,⟨32,1024,2048,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,0,16,32⟩,⟨32,1024,2048,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,4,16,32⟩,⟨32,1024,2048,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨8,16,32,0⟩,⟨32,1024,2048,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,32,4⟩,⟨32,1024,2048,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,32,4,0⟩,⟨32,1024,2048,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,32,4,0⟩,⟨64,1024,2048,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,8,32,4⟩,⟨64,1024,2048,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,0,0⟩,⟨4,8,32,4⟩,⟨64,1024,2048,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,8,32,8⟩,⟨64,1024,2048,65536⟩⟩
def b30 : Board := ⟨⟨4,0,0,4⟩,⟨0,0,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,2048,65536⟩⟩
def b31 : Board := ⟨⟨8,0,0,0⟩,⟨4,0,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,2048,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,8⟩,⟨4,0,0,4⟩,⟨0,16,32,8⟩,⟨64,1024,2048,65536⟩⟩
def b33 : Board := ⟨⟨8,0,0,0⟩,⟨8,4,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,2048,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨16,32,8,0⟩,⟨64,1024,2048,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,4,0⟩,⟨32,32,8,4⟩,⟨64,1024,2048,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨64,8,4,0⟩,⟨64,1024,2048,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,4⟩,⟨128,1024,2048,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,1024,2048,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,1024,2048,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,1024,2048,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,1024,2048,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,1024,2048,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,1024,2048,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,1024,2048,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,1024,2048,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,1024,2048,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,1024,2048,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,1024,2048,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,1024,2048,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,1024,2048,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,1024,2048,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,1024,2048,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,1024,2048,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,1024,2048,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,1024,2048,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,1024,2048,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,1024,2048,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,1024,2048,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,1024,2048,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,1024,2048,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,1024,2048,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,1024,2048,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,1024,2048,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,1024,2048,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,1024,2048,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,1024,2048,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,1024,2048,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,1024,2048,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,1024,2048,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,1024,2048,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,1024,2048,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,1024,2048,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,1024,2048,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,1024,2048,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,1024,2048,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,1024,2048,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,1024,2048,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,1024,2048,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,1024,2048,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,1024,2048,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,1024,2048,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,1024,2048,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,1024,2048,65536⟩⟩
def b128 : Board := c0135
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0134
theorem chunk0134 : Plays c0134 128 c0135 :=
  Segment0134.p128

namespace Segment0135
def b0 : Board := c0135
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,1024,2048,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,0⟩,⟨128,64,32,32⟩,⟨256,1024,2048,65536⟩⟩
def b3 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,0,0⟩,⟨128,64,64,0⟩,⟨256,1024,2048,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,8⟩,⟨4,0,4,8⟩,⟨0,0,128,128⟩,⟨256,1024,2048,65536⟩⟩
def b5 : Board := ⟨⟨8,0,0,0⟩,⟨8,8,4,0⟩,⟨256,0,0,0⟩,⟨256,1024,2048,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨16,16,4,0⟩,⟨512,1024,2048,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,16,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨32,16,8,0⟩,⟨512,1024,2048,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨512,1024,2048,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨512,1024,2048,65536⟩⟩
def b17 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨32,32,4,0⟩,⟨512,1024,2048,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨512,1024,2048,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨512,1024,2048,65536⟩⟩
def b26 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b27 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨512,1024,2048,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨512,1024,2048,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨512,1024,2048,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨512,1024,2048,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨512,1024,2048,65536⟩⟩
def b41 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨512,1024,2048,65536⟩⟩
def b42 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b43 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨512,1024,2048,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨512,1024,2048,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨512,1024,2048,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b65 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨512,1024,2048,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨512,1024,2048,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,8,4,0⟩,⟨512,1024,2048,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,8⟩,⟨512,1024,2048,65536⟩⟩
def b73 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,16,4⟩,⟨512,1024,2048,65536⟩⟩
def b74 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b75 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,32,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,32,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,16⟩,⟨512,1024,2048,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,32,32,4⟩,⟨512,1024,2048,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,64,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨256,64,8,0⟩,⟨512,1024,2048,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,64,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,64,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨256,64,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨256,64,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨256,64,32,32⟩,⟨512,1024,2048,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,64,64,4⟩,⟨512,1024,2048,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,128,4,4⟩,⟨512,1024,2048,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,4⟩,⟨512,1024,2048,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,8⟩,⟨512,1024,2048,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,4,0⟩,⟨256,128,16,0⟩,⟨512,1024,2048,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,4⟩,⟨512,1024,2048,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨256,128,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨0,4,16,4⟩,⟨256,128,16,8⟩,⟨512,1024,2048,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨256,128,32,8⟩,⟨512,1024,2048,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨256,128,32,8⟩,⟨512,1024,2048,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,8,0⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b115 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b116 : Board := ⟨⟨0,4,0,0⟩,⟨8,8,16,4⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b117 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,32,8⟩,⟨256,128,32,16⟩,⟨512,1024,2048,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,64,16⟩,⟨512,1024,2048,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,16⟩,⟨512,1024,2048,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,64,16⟩,⟨512,1024,2048,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,16⟩,⟨512,1024,2048,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b127 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b128 : Board := c0136
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
end Segment0135
theorem chunk0135 : Plays c0135 128 c0136 :=
  Segment0135.p128

namespace Segment0136
def b0 : Board := c0136
def b1 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨512,1024,2048,65536⟩⟩
def b7 : Board := ⟨⟨0,4,0,0⟩,⟨4,8,16,4⟩,⟨256,128,64,64⟩,⟨512,1024,2048,65536⟩⟩
def b8 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,128,4⟩,⟨512,1024,2048,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,16,4⟩,⟨256,128,128,8⟩,⟨512,1024,2048,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨16,16,4,4⟩,⟨256,256,8,0⟩,⟨512,1024,2048,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨32,8,0,0⟩,⟨512,8,4,0⟩,⟨512,1024,2048,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,0⟩,⟨1024,1024,2048,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,32,16,4⟩,⟨0,2048,2048,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨32,16,4,4⟩,⟨4096,65536,0,0⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,32,16,8⟩,⟨0,0,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,16⟩,⟨4,32,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,32,0,0⟩,⟨4,32,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,64,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,64,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,64,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,64,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨16,64,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨16,64,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨16,64,4096,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨16,64,4096,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,8,4,4⟩,⟨32,64,4096,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨8,8,4,0⟩,⟨32,64,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨32,64,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨32,64,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨32,64,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨32,64,4096,65536⟩⟩
def b33 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨32,64,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨32,64,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨32,64,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨32,64,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b40 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b41 : Board := ⟨⟨8,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b42 : Board := ⟨⟨8,4,0,4⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b43 : Board := ⟨⟨0,0,8,8⟩,⟨0,4,0,4⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,16⟩,⟨0,4,0,8⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,16⟩,⟨4,0,4,8⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b46 : Board := ⟨⟨16,0,0,4⟩,⟨8,8,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b47 : Board := ⟨⟨16,4,0,4⟩,⟨16,0,0,0⟩,⟨32,16,8,4⟩,⟨32,64,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨32,16,8,8⟩,⟨64,64,4096,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,4⟩,⟨32,16,8,8⟩,⟨64,64,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,4,0,0⟩,⟨0,4,0,8⟩,⟨32,16,8,8⟩,⟨64,64,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨32,16,8,16⟩,⟨64,64,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨32,16,8,16⟩,⟨0,128,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨0,16,16,16⟩,⟨32,128,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨32,16,4,0⟩,⟨32,128,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,0⟩,⟨4,16,4,0⟩,⟨64,128,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨0,8,4,0⟩,⟨8,16,4,0⟩,⟨64,128,4096,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨8,16,4,0⟩,⟨64,128,4096,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,8,4⟩,⟨64,128,4096,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,128,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,128,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,128,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,128,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,128,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,128,4096,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨64,128,4096,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,0,0⟩,⟨64,128,4096,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨64,4,0,0⟩,⟨64,128,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨128,128,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,0,16,4⟩,⟨4,256,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨4,256,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨8,256,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,4,16,8⟩,⟨8,256,4096,65536⟩⟩
def b73 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,0⟩,⟨8,256,4096,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨16,256,4096,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨16,8,4,0⟩,⟨16,256,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨8,8,4,0⟩,⟨32,256,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,4,4,0⟩,⟨32,256,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨16,8,4,0⟩,⟨32,256,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨32,256,4096,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨32,256,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨32,256,4096,65536⟩⟩
def b83 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,256,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,256,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,256,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,256,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,256,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,256,4096,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,256,4096,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,256,4096,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,256,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,256,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,256,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,256,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,256,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,256,4096,65536⟩⟩
def b97 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,256,4096,65536⟩⟩
def b98 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,256,4096,65536⟩⟩
def b99 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,256,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,256,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,256,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,256,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,256,4096,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b107 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,256,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,256,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,256,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,256,4096,65536⟩⟩
def b113 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,256,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,256,4096,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,256,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,256,4096,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,256,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,256,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,256,4096,65536⟩⟩
def b121 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,256,4096,65536⟩⟩
def b122 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,256,4096,65536⟩⟩
def b123 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,256,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,256,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,256,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,256,4096,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,256,4096,65536⟩⟩
def b128 : Board := c0137
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
end Segment0136
theorem chunk0136 : Plays c0136 128 c0137 :=
  Segment0136.p128

namespace Segment0137
def b0 : Board := c0137
def b1 : Board := ⟨⟨0,0,4,0⟩,⟨8,0,0,0⟩,⟨64,32,32,0⟩,⟨128,256,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨64,32,32,0⟩,⟨128,256,4096,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨64,64,4,0⟩,⟨128,256,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,0,0⟩,⟨128,4,0,0⟩,⟨128,256,4096,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,256,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨0,16,8,4⟩,⟨4,512,4096,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨4,512,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,16,8,4⟩,⟨4,512,4096,65536⟩⟩
def b9 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨4,16,8,4⟩,⟨4,512,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,16,8,4⟩,⟨8,512,4096,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨0,16,8,8⟩,⟨16,512,4096,65536⟩⟩
def b12 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,0,0⟩,⟨16,512,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,16,0,0⟩,⟨32,512,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,0,8,16⟩,⟨32,512,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,16,0,0⟩,⟨32,512,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,0⟩,⟨16,16,4,0⟩,⟨32,512,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,4,0,4⟩,⟨32,512,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨32,512,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨64,512,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨64,512,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨64,512,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨64,512,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨64,512,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨64,512,4096,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨64,512,4096,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨64,512,4096,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨64,512,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨64,512,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨64,512,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨64,512,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨64,512,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨64,512,4096,65536⟩⟩
def b33 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨64,512,4096,65536⟩⟩
def b34 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,4⟩,⟨32,32,4,0⟩,⟨64,512,4096,65536⟩⟩
def b35 : Board := ⟨⟨4,0,0,0⟩,⟨8,4,0,0⟩,⟨64,4,0,0⟩,⟨64,512,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,0⟩,⟨128,512,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,4,4,0⟩,⟨128,512,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,512,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,512,4096,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,512,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,512,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,512,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,512,4096,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,512,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,512,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,512,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,512,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,512,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,512,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,512,4096,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,512,4096,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,512,4096,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,512,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,512,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,512,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,512,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,512,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,512,4096,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,512,4096,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,512,4096,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,512,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,512,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,512,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,512,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,512,4096,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,512,4096,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,512,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,512,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,512,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,512,4096,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,512,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,512,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,512,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,512,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,512,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,512,4096,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,512,4096,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,512,4096,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,512,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,512,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,512,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,512,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,512,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,512,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,512,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,512,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,512,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,512,4096,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,512,4096,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,512,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,512,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,512,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,512,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,512,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,512,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,512,4096,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,512,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,512,4096,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,512,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,512,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,512,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,512,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,512,4096,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,512,4096,65536⟩⟩
def b128 : Board := c0138
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0137
theorem chunk0137 : Plays c0137 128 c0138 :=
  Segment0137.p128

namespace Segment0138
def b0 : Board := c0138
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,512,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨256,512,4096,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨256,512,4096,65536⟩⟩
def b4 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,0⟩,⟨256,512,4096,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,0,0⟩,⟨128,128,8,4⟩,⟨256,512,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨16,0,0,0⟩,⟨256,8,4,0⟩,⟨256,512,4096,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨512,512,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,16,8,8⟩,⟨4,1024,4096,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,0,16,16⟩,⟨4,1024,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,0,16,16⟩,⟨8,1024,4096,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,0,4,32⟩,⟨8,1024,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,4,4,32⟩,⟨8,1024,4096,65536⟩⟩
def b13 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,32,0⟩,⟨8,1024,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,4,32,0⟩,⟨16,1024,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,8,4,32⟩,⟨16,1024,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,0,0⟩,⟨8,4,32,0⟩,⟨16,1024,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,32,0⟩,⟨16,1024,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨4,8,32,0⟩,⟨32,1024,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,32,0⟩,⟨32,1024,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,0,0⟩,⟨16,32,0,0⟩,⟨32,1024,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,0,16,32⟩,⟨32,1024,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,8⟩,⟨4,4,16,32⟩,⟨32,1024,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨8,16,32,0⟩,⟨32,1024,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,32,4⟩,⟨32,1024,4096,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨32,32,4,0⟩,⟨32,1024,4096,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,32,4,0⟩,⟨64,1024,4096,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,8,32,4⟩,⟨64,1024,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,0,0⟩,⟨4,8,32,4⟩,⟨64,1024,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,8,32,8⟩,⟨64,1024,4096,65536⟩⟩
def b30 : Board := ⟨⟨4,0,0,4⟩,⟨0,0,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,4096,65536⟩⟩
def b31 : Board := ⟨⟨8,0,0,0⟩,⟨4,0,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,8⟩,⟨4,0,0,4⟩,⟨0,16,32,8⟩,⟨64,1024,4096,65536⟩⟩
def b33 : Board := ⟨⟨8,0,0,0⟩,⟨8,4,0,0⟩,⟨16,32,8,0⟩,⟨64,1024,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨16,32,8,0⟩,⟨64,1024,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,4,0⟩,⟨32,32,8,4⟩,⟨64,1024,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨64,8,4,0⟩,⟨64,1024,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨8,8,4,4⟩,⟨128,1024,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,0⟩,⟨128,1024,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨0,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,8⟩,⟨0,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨16,8,4,0⟩,⟨128,1024,4096,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨128,1024,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,1024,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,1024,4096,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,1024,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,1024,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,1024,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,1024,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,1024,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,1024,4096,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,1024,4096,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,1024,4096,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,1024,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,1024,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,1024,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,1024,4096,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,1024,4096,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,1024,4096,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,1024,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,1024,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,1024,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,1024,4096,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,1024,4096,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,1024,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,1024,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,1024,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,1024,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,1024,4096,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,1024,4096,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,1024,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,1024,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,1024,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,1024,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,1024,4096,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,1024,4096,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,1024,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,1024,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,1024,4096,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,1024,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,1024,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,1024,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,1024,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,1024,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,1024,4096,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,1024,4096,65536⟩⟩
def b128 : Board := c0139
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i2, .i1, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.right, .i2, .i0, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i1, .i0, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0138
theorem chunk0138 : Plays c0138 128 c0139 :=
  Segment0138.p128

namespace Segment0139
def b0 : Board := c0139
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,1024,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,0⟩,⟨128,64,32,32⟩,⟨256,1024,4096,65536⟩⟩
def b3 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,0,0⟩,⟨128,64,64,0⟩,⟨256,1024,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,8⟩,⟨4,0,4,8⟩,⟨0,0,128,128⟩,⟨256,1024,4096,65536⟩⟩
def b5 : Board := ⟨⟨8,0,0,0⟩,⟨8,8,4,0⟩,⟨256,0,0,0⟩,⟨256,1024,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨16,16,4,0⟩,⟨512,1024,4096,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,16,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨32,16,8,0⟩,⟨512,1024,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨512,1024,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨512,1024,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨32,32,4,0⟩,⟨512,1024,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨512,1024,4096,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨512,1024,4096,65536⟩⟩
def b26 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b27 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨512,1024,4096,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨512,1024,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨512,1024,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨512,1024,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨512,1024,4096,65536⟩⟩
def b41 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨512,1024,4096,65536⟩⟩
def b42 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b43 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨512,1024,4096,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨512,1024,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨512,1024,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b65 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨512,1024,4096,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨512,1024,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,8,4,0⟩,⟨512,1024,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,8⟩,⟨512,1024,4096,65536⟩⟩
def b73 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,16,4⟩,⟨512,1024,4096,65536⟩⟩
def b74 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b75 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,32,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,32,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,16⟩,⟨512,1024,4096,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,32,32,4⟩,⟨512,1024,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,64,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨256,64,8,0⟩,⟨512,1024,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,64,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,64,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨256,64,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨256,64,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨256,64,32,32⟩,⟨512,1024,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,64,64,4⟩,⟨512,1024,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,128,4,4⟩,⟨512,1024,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,4⟩,⟨512,1024,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,8⟩,⟨512,1024,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,4,0⟩,⟨256,128,16,0⟩,⟨512,1024,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,4⟩,⟨512,1024,4096,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨256,128,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨0,4,16,4⟩,⟨256,128,16,8⟩,⟨512,1024,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨256,128,32,8⟩,⟨512,1024,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨256,128,32,8⟩,⟨512,1024,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,8,0⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b115 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,4,0,0⟩,⟨8,8,16,4⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b117 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,32,8⟩,⟨256,128,32,16⟩,⟨512,1024,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,64,16⟩,⟨512,1024,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,16⟩,⟨512,1024,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,64,16⟩,⟨512,1024,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,16⟩,⟨512,1024,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b127 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b128 : Board := c0140
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
end Segment0139
theorem chunk0139 : Plays c0139 128 c0140 :=
  Segment0139.p128

namespace Segment0140
def b0 : Board := c0140
def b1 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨512,1024,4096,65536⟩⟩
def b7 : Board := ⟨⟨0,4,0,0⟩,⟨4,8,16,4⟩,⟨256,128,64,64⟩,⟨512,1024,4096,65536⟩⟩
def b8 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,128,4⟩,⟨512,1024,4096,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,16,4⟩,⟨256,128,128,8⟩,⟨512,1024,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨16,16,4,4⟩,⟨256,256,8,0⟩,⟨512,1024,4096,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨32,8,0,0⟩,⟨512,8,4,0⟩,⟨512,1024,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,0⟩,⟨1024,1024,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨0,32,16,4⟩,⟨4,2048,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨4,32,16,8⟩,⟨4,2048,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨0,32,16,8⟩,⟨8,2048,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨4,32,16,8⟩,⟨8,2048,4096,65536⟩⟩
def b17 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨4,32,16,8⟩,⟨8,2048,4096,65536⟩⟩
def b18 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨8,32,16,8⟩,⟨8,2048,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,32,16,8⟩,⟨16,2048,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,0,4⟩,⟨8,32,16,8⟩,⟨16,2048,4096,65536⟩⟩
def b21 : Board := ⟨⟨4,0,0,0⟩,⟨8,0,0,0⟩,⟨8,32,16,8⟩,⟨16,2048,4096,65536⟩⟩
def b22 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨16,32,16,8⟩,⟨16,2048,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨8,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b24 : Board := ⟨⟨4,0,0,4⟩,⟨0,0,0,0⟩,⟨8,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b25 : Board := ⟨⟨8,0,0,4⟩,⟨0,0,0,0⟩,⟨8,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨16,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b27 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨16,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,8⟩,⟨0,4,0,4⟩,⟨16,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b29 : Board := ⟨⟨8,4,0,0⟩,⟨8,0,0,0⟩,⟨16,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b30 : Board := ⟨⟨4,0,0,0⟩,⟨16,4,0,0⟩,⟨16,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b31 : Board := ⟨⟨4,0,0,0⟩,⟨4,4,0,0⟩,⟨32,32,16,8⟩,⟨32,2048,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,0,0⟩,⟨8,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b33 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨8,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,4⟩,⟨8,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,8⟩,⟨16,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b36 : Board := ⟨⟨4,0,0,4⟩,⟨8,0,0,0⟩,⟨16,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b37 : Board := ⟨⟨8,0,0,4⟩,⟨8,0,0,0⟩,⟨16,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,4⟩,⟨16,0,0,4⟩,⟨16,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,8⟩,⟨32,32,16,8⟩,⟨64,2048,4096,65536⟩⟩
def b40 : Board := ⟨⟨4,0,0,0⟩,⟨8,0,0,0⟩,⟨64,16,8,4⟩,⟨64,2048,4096,65536⟩⟩
def b41 : Board := ⟨⟨0,0,4,4⟩,⟨0,0,0,8⟩,⟨64,16,8,4⟩,⟨64,2048,4096,65536⟩⟩
def b42 : Board := ⟨⟨8,0,0,4⟩,⟨8,0,0,0⟩,⟨64,16,8,4⟩,⟨64,2048,4096,65536⟩⟩
def b43 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨16,16,8,8⟩,⟨128,2048,4096,65536⟩⟩
def b44 : Board := ⟨⟨4,0,0,0⟩,⟨0,0,0,0⟩,⟨32,16,4,0⟩,⟨128,2048,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨128,2048,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨128,2048,4096,65536⟩⟩
def b49 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨128,2048,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨128,2048,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨128,2048,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨128,2048,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨128,2048,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨128,2048,4096,65536⟩⟩
def b57 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨128,2048,4096,65536⟩⟩
def b58 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨128,2048,4096,65536⟩⟩
def b59 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨128,2048,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨128,2048,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨128,2048,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,4,0⟩,⟨64,32,16,16⟩,⟨128,2048,4096,65536⟩⟩
def b65 : Board := ⟨⟨4,0,0,4⟩,⟨4,0,0,0⟩,⟨64,32,32,0⟩,⟨128,2048,4096,65536⟩⟩
def b66 : Board := ⟨⟨8,0,0,0⟩,⟨4,4,0,0⟩,⟨64,64,0,0⟩,⟨128,2048,4096,65536⟩⟩
def b67 : Board := ⟨⟨8,0,0,0⟩,⟨8,0,0,0⟩,⟨128,4,0,0⟩,⟨128,2048,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,4,4,0⟩,⟨256,2048,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,0⟩,⟨256,2048,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨0,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,8,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b73 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨16,16,4,0⟩,⟨256,2048,4096,65536⟩⟩
def b74 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨16,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b75 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨256,2048,4096,65536⟩⟩
def b81 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨256,2048,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨256,2048,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨256,2048,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨256,2048,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨256,2048,4096,65536⟩⟩
def b89 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨256,2048,4096,65536⟩⟩
def b90 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b91 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨256,2048,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨256,2048,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨256,2048,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨256,2048,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨256,2048,4096,65536⟩⟩
def b105 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨256,2048,4096,65536⟩⟩
def b106 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨256,2048,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨256,2048,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨256,2048,4096,65536⟩⟩
def b115 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨256,2048,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b117 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨256,2048,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨256,2048,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨256,2048,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨256,2048,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨256,2048,4096,65536⟩⟩
def b127 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨256,2048,4096,65536⟩⟩
def b128 : Board := c0141
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.right, .i3, .i0, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i2, .i0, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i0, .i0, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.left, .i0, .i1, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.right, .i0, .i2, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.left, .i1, .i1, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i1, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.down, .i2, .i2, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
end Segment0140
theorem chunk0140 : Plays c0140 128 c0141 :=
  Segment0140.p128

namespace Segment0141
def b0 : Board := c0141
def b1 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨256,2048,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,0⟩,⟨128,64,32,32⟩,⟨256,2048,4096,65536⟩⟩
def b3 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,0,0⟩,⟨128,64,64,0⟩,⟨256,2048,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,8⟩,⟨4,0,4,8⟩,⟨0,0,128,128⟩,⟨256,2048,4096,65536⟩⟩
def b5 : Board := ⟨⟨8,0,0,0⟩,⟨8,8,4,0⟩,⟨256,0,0,0⟩,⟨256,2048,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b7 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,8,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨0,0,0,0⟩,⟨16,16,4,0⟩,⟨512,2048,4096,65536⟩⟩
def b9 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨16,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b11 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,8,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,0⟩,⟨32,16,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,0⟩,⟨32,16,8,0⟩,⟨512,2048,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨512,2048,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,16,4⟩,⟨512,2048,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,4,0⟩,⟨4,0,0,0⟩,⟨32,32,4,0⟩,⟨512,2048,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,8,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨512,2048,4096,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨512,2048,4096,65536⟩⟩
def b26 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b27 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨512,2048,4096,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨512,2048,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨512,2048,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨512,2048,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨512,2048,4096,65536⟩⟩
def b41 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨512,2048,4096,65536⟩⟩
def b42 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b43 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨512,2048,4096,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨512,2048,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨512,2048,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b65 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨512,2048,4096,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨512,2048,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,8,4,0⟩,⟨512,2048,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,8⟩,⟨512,2048,4096,65536⟩⟩
def b73 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,16,4⟩,⟨512,2048,4096,65536⟩⟩
def b74 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b75 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,32,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,32,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,16⟩,⟨512,2048,4096,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,32,32,4⟩,⟨512,2048,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,64,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨256,64,8,0⟩,⟨512,2048,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,64,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,64,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨256,64,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨256,64,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨256,64,32,32⟩,⟨512,2048,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,64,64,4⟩,⟨512,2048,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,128,4,4⟩,⟨512,2048,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,4⟩,⟨512,2048,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,8⟩,⟨512,2048,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,4,0⟩,⟨256,128,16,0⟩,⟨512,2048,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,4⟩,⟨512,2048,4096,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨256,128,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨0,4,16,4⟩,⟨256,128,16,8⟩,⟨512,2048,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨256,128,32,8⟩,⟨512,2048,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨256,128,32,8⟩,⟨512,2048,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,8,0⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b115 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,4,0,0⟩,⟨8,8,16,4⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b117 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,32,8⟩,⟨256,128,32,16⟩,⟨512,2048,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,64,16⟩,⟨512,2048,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,16⟩,⟨512,2048,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,64,16⟩,⟨512,2048,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,16⟩,⟨512,2048,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b127 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b128 : Board := c0142
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
end Segment0141
theorem chunk0141 : Plays c0141 128 c0142 :=
  Segment0141.p128

namespace Segment0142
def b0 : Board := c0142
def b1 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b7 : Board := ⟨⟨4,0,4,0⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨512,2048,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨8,8,16,4⟩,⟨256,128,64,64⟩,⟨512,2048,4096,65536⟩⟩
def b9 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,128,0⟩,⟨512,2048,4096,65536⟩⟩
def b10 : Board := ⟨⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨256,256,0,0⟩,⟨512,2048,4096,65536⟩⟩
def b11 : Board := ⟨⟨4,0,0,0⟩,⟨32,8,4,0⟩,⟨512,0,4,0⟩,⟨512,2048,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,8,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨32,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨32,16,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b17 : Board := ⟨⟨4,0,4,0⟩,⟨4,0,0,0⟩,⟨32,16,16,0⟩,⟨1024,2048,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨8,4,4,0⟩,⟨32,16,16,0⟩,⟨1024,2048,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨0,0,32,32⟩,⟨1024,2048,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨4,16,4,0⟩,⟨64,0,0,0⟩,⟨1024,2048,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨64,16,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b25 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,16,16,4⟩,⟨1024,2048,4096,65536⟩⟩
def b26 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b27 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨64,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨64,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨64,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨64,32,16,16⟩,⟨1024,2048,4096,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨64,32,32,0⟩,⟨1024,2048,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,4⟩,⟨0,0,64,64⟩,⟨1024,2048,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,0,4,0⟩,⟨1024,2048,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,8,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨128,16,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b41 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,16,16,4⟩,⟨1024,2048,4096,65536⟩⟩
def b42 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b43 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨128,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,32,16,16⟩,⟨1024,2048,4096,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,32,32,4⟩,⟨1024,2048,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨128,64,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b51 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨128,64,8,0⟩,⟨1024,2048,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨128,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b53 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨128,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨128,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b63 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b64 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b65 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨128,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨128,64,32,32⟩,⟨1024,2048,4096,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,64,64,4⟩,⟨1024,2048,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨128,128,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,8,4,0⟩,⟨1024,2048,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b71 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,0,4⟩,⟨256,16,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b73 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,16,16,4⟩,⟨1024,2048,4096,65536⟩⟩
def b74 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b75 : Board := ⟨⟨4,0,0,0⟩,⟨4,0,0,0⟩,⟨256,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b76 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b77 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b78 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b79 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,32,16,16⟩,⟨1024,2048,4096,65536⟩⟩
def b81 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,32,32,4⟩,⟨1024,2048,4096,65536⟩⟩
def b82 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨256,64,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨256,64,8,0⟩,⟨1024,2048,4096,65536⟩⟩
def b84 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨256,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨256,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨256,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b95 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b96 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨256,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨256,64,32,32⟩,⟨1024,2048,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,64,64,4⟩,⟨1024,2048,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨256,128,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨256,128,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b103 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,4,0⟩,⟨256,128,16,0⟩,⟨1024,2048,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,4⟩,⟨1024,2048,4096,65536⟩⟩
def b105 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨256,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b106 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨256,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b107 : Board := ⟨⟨4,0,0,0⟩,⟨0,4,16,4⟩,⟨256,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b108 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨256,128,32,8⟩,⟨1024,2048,4096,65536⟩⟩
def b109 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨256,128,32,8⟩,⟨1024,2048,4096,65536⟩⟩
def b110 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,8,0⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b111 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b114 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b115 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b116 : Board := ⟨⟨0,4,0,0⟩,⟨8,8,16,4⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b117 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b118 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,32,8⟩,⟨256,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b119 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨256,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨256,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b127 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b128 : Board := c0143
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.down, .i1, .i1, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.left, .i1, .i2, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.down, .i2, .i3, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
end Segment0142
theorem chunk0142 : Plays c0142 128 c0143 :=
  Segment0142.p128

namespace Segment0143
def b0 : Board := c0143
def b1 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b2 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b3 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b4 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b5 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b6 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b7 : Board := ⟨⟨4,0,4,0⟩,⟨4,8,16,32⟩,⟨256,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b8 : Board := ⟨⟨0,0,4,0⟩,⟨8,8,16,4⟩,⟨256,128,64,64⟩,⟨1024,2048,4096,65536⟩⟩
def b9 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨256,128,128,0⟩,⟨1024,2048,4096,65536⟩⟩
def b10 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,32,8⟩,⟨0,0,256,256⟩,⟨1024,2048,4096,65536⟩⟩
def b11 : Board := ⟨⟨4,0,0,0⟩,⟨4,32,8,4⟩,⟨512,0,0,0⟩,⟨1024,2048,4096,65536⟩⟩
def b12 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨512,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b13 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨512,32,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b14 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨512,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b15 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨512,32,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b16 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨512,32,16,16⟩,⟨1024,2048,4096,65536⟩⟩
def b17 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨512,32,32,4⟩,⟨1024,2048,4096,65536⟩⟩
def b18 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,0⟩,⟨512,64,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b19 : Board := ⟨⟨0,0,0,4⟩,⟨8,0,0,0⟩,⟨512,64,8,0⟩,⟨1024,2048,4096,65536⟩⟩
def b20 : Board := ⟨⟨0,0,0,0⟩,⟨8,0,0,4⟩,⟨512,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b21 : Board := ⟨⟨0,0,0,4⟩,⟨0,0,8,4⟩,⟨512,64,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b22 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,4⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b23 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b24 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b25 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,4⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b26 : Board := ⟨⟨0,0,0,0⟩,⟨8,8,4,4⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b27 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,16,8⟩,⟨512,64,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b28 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,0,4⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b29 : Board := ⟨⟨0,0,0,0⟩,⟨0,0,4,8⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b30 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b31 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b32 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,8,8⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b33 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,16⟩,⟨512,64,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b34 : Board := ⟨⟨0,0,0,0⟩,⟨0,4,8,4⟩,⟨512,64,32,32⟩,⟨1024,2048,4096,65536⟩⟩
def b35 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨512,64,64,4⟩,⟨1024,2048,4096,65536⟩⟩
def b36 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,0⟩,⟨512,128,4,4⟩,⟨1024,2048,4096,65536⟩⟩
def b37 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨512,128,8,4⟩,⟨1024,2048,4096,65536⟩⟩
def b38 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,0,4⟩,⟨512,128,8,8⟩,⟨1024,2048,4096,65536⟩⟩
def b39 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,4,0⟩,⟨512,128,16,0⟩,⟨1024,2048,4096,65536⟩⟩
def b40 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨512,128,16,4⟩,⟨1024,2048,4096,65536⟩⟩
def b41 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,4,4⟩,⟨512,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b42 : Board := ⟨⟨0,0,0,0⟩,⟨4,8,8,4⟩,⟨512,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b43 : Board := ⟨⟨4,0,0,0⟩,⟨0,4,16,4⟩,⟨512,128,16,8⟩,⟨1024,2048,4096,65536⟩⟩
def b44 : Board := ⟨⟨0,0,0,0⟩,⟨4,4,4,4⟩,⟨512,128,32,8⟩,⟨1024,2048,4096,65536⟩⟩
def b45 : Board := ⟨⟨0,0,0,0⟩,⟨4,0,8,8⟩,⟨512,128,32,8⟩,⟨1024,2048,4096,65536⟩⟩
def b46 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,8,0⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b47 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b48 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b49 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b50 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b51 : Board := ⟨⟨4,0,0,0⟩,⟨4,8,16,4⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b52 : Board := ⟨⟨0,4,0,0⟩,⟨8,8,16,4⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b53 : Board := ⟨⟨4,0,0,0⟩,⟨16,16,4,4⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b54 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,32,8⟩,⟨512,128,32,16⟩,⟨1024,2048,4096,65536⟩⟩
def b55 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,8⟩,⟨512,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b56 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨512,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b57 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨512,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b58 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨512,128,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b59 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b60 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b61 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b62 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b63 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b64 : Board := ⟨⟨8,0,0,4⟩,⟨4,8,16,0⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b65 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b66 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b67 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b68 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b69 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b70 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b71 : Board := ⟨⟨4,0,4,0⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b72 : Board := ⟨⟨0,4,0,8⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b73 : Board := ⟨⟨0,4,4,8⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b74 : Board := ⟨⟨0,4,8,8⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b75 : Board := ⟨⟨0,4,4,16⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b76 : Board := ⟨⟨4,0,8,16⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b77 : Board := ⟨⟨4,4,8,16⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b78 : Board := ⟨⟨4,8,8,16⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b79 : Board := ⟨⟨4,4,16,16⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b80 : Board := ⟨⟨0,4,8,32⟩,⟨4,8,16,32⟩,⟨512,128,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b81 : Board := ⟨⟨0,4,8,4⟩,⟨4,8,16,32⟩,⟨512,128,64,64⟩,⟨1024,2048,4096,65536⟩⟩
def b82 : Board := ⟨⟨4,8,4,4⟩,⟨4,8,16,32⟩,⟨512,128,128,0⟩,⟨1024,2048,4096,65536⟩⟩
def b83 : Board := ⟨⟨0,4,4,0⟩,⟨8,16,16,4⟩,⟨512,128,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b84 : Board := ⟨⟨8,0,0,0⟩,⟨8,32,4,0⟩,⟨512,256,32,4⟩,⟨1024,2048,4096,65536⟩⟩
def b85 : Board := ⟨⟨0,0,4,8⟩,⟨0,8,32,4⟩,⟨512,256,32,4⟩,⟨1024,2048,4096,65536⟩⟩
def b86 : Board := ⟨⟨0,0,0,4⟩,⟨0,8,4,8⟩,⟨512,256,64,8⟩,⟨1024,2048,4096,65536⟩⟩
def b87 : Board := ⟨⟨0,0,0,4⟩,⟨0,8,4,4⟩,⟨512,256,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b88 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨512,256,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b89 : Board := ⟨⟨0,0,0,4⟩,⟨4,0,4,16⟩,⟨512,256,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b90 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨512,256,64,16⟩,⟨1024,2048,4096,65536⟩⟩
def b91 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,4⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b92 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,8⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b93 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,4,16⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b94 : Board := ⟨⟨0,0,0,4⟩,⟨0,4,8,16⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b95 : Board := ⟨⟨4,0,0,4⟩,⟨4,8,16,0⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b96 : Board := ⟨⟨8,0,0,4⟩,⟨4,8,16,0⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b97 : Board := ⟨⟨0,4,8,4⟩,⟨0,4,8,16⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b98 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,16⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b99 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,8,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b100 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,8,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b101 : Board := ⟨⟨0,0,0,4⟩,⟨4,4,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b102 : Board := ⟨⟨0,0,0,4⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b103 : Board := ⟨⟨4,0,4,0⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b104 : Board := ⟨⟨0,4,0,8⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b105 : Board := ⟨⟨0,4,4,8⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b106 : Board := ⟨⟨0,4,8,8⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b107 : Board := ⟨⟨0,4,4,16⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b108 : Board := ⟨⟨4,0,8,16⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b109 : Board := ⟨⟨4,4,8,16⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b110 : Board := ⟨⟨4,8,8,16⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b111 : Board := ⟨⟨4,4,16,16⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b112 : Board := ⟨⟨0,4,8,32⟩,⟨4,8,16,32⟩,⟨512,256,64,32⟩,⟨1024,2048,4096,65536⟩⟩
def b113 : Board := ⟨⟨0,4,8,4⟩,⟨4,8,16,32⟩,⟨512,256,64,64⟩,⟨1024,2048,4096,65536⟩⟩
def b114 : Board := ⟨⟨4,8,4,0⟩,⟨4,8,16,32⟩,⟨512,256,128,4⟩,⟨1024,2048,4096,65536⟩⟩
def b115 : Board := ⟨⟨4,4,8,4⟩,⟨4,8,16,32⟩,⟨512,256,128,4⟩,⟨1024,2048,4096,65536⟩⟩
def b116 : Board := ⟨⟨4,4,8,4⟩,⟨8,8,16,32⟩,⟨512,256,128,4⟩,⟨1024,2048,4096,65536⟩⟩
def b117 : Board := ⟨⟨4,8,8,4⟩,⟨0,16,16,32⟩,⟨512,256,128,4⟩,⟨1024,2048,4096,65536⟩⟩
def b118 : Board := ⟨⟨4,16,4,0⟩,⟨32,32,0,4⟩,⟨512,256,128,4⟩,⟨1024,2048,4096,65536⟩⟩
def b119 : Board := ⟨⟨4,16,0,0⟩,⟨32,32,4,4⟩,⟨512,256,128,8⟩,⟨1024,2048,4096,65536⟩⟩
def b120 : Board := ⟨⟨0,0,4,16⟩,⟨4,0,64,8⟩,⟨512,256,128,8⟩,⟨1024,2048,4096,65536⟩⟩
def b121 : Board := ⟨⟨0,0,4,4⟩,⟨4,0,64,16⟩,⟨512,256,128,16⟩,⟨1024,2048,4096,65536⟩⟩
def b122 : Board := ⟨⟨0,0,4,4⟩,⟨4,0,64,4⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b123 : Board := ⟨⟨0,0,4,4⟩,⟨4,0,64,8⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b124 : Board := ⟨⟨0,0,4,8⟩,⟨0,4,64,8⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b125 : Board := ⟨⟨0,0,4,4⟩,⟨0,4,64,16⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b126 : Board := ⟨⟨0,4,0,8⟩,⟨0,4,64,16⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b127 : Board := ⟨⟨0,4,4,8⟩,⟨0,4,64,16⟩,⟨512,256,128,32⟩,⟨1024,2048,4096,65536⟩⟩
def b128 : Board := c0144
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p14 : Plays b0 14 b14 :=
  Plays.snoc p13 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p15 : Plays b0 15 b15 :=
  Plays.snoc p14 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p16 : Plays b0 16 b16 :=
  Plays.snoc p15 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p17 : Plays b0 17 b17 :=
  Plays.snoc p16 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p18 : Plays b0 18 b18 :=
  Plays.snoc p17 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p19 : Plays b0 19 b19 :=
  Plays.snoc p18 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p20 : Plays b0 20 b20 :=
  Plays.snoc p19 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p21 : Plays b0 21 b21 :=
  Plays.snoc p20 ⟨.right, .i0, .i3, 4⟩ (by decide +kernel)
theorem p22 : Plays b0 22 b22 :=
  Plays.snoc p21 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p23 : Plays b0 23 b23 :=
  Plays.snoc p22 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p24 : Plays b0 24 b24 :=
  Plays.snoc p23 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p25 : Plays b0 25 b25 :=
  Plays.snoc p24 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p26 : Plays b0 26 b26 :=
  Plays.snoc p25 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p27 : Plays b0 27 b27 :=
  Plays.snoc p26 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p28 : Plays b0 28 b28 :=
  Plays.snoc p27 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p29 : Plays b0 29 b29 :=
  Plays.snoc p28 ⟨.right, .i1, .i2, 4⟩ (by decide +kernel)
theorem p30 : Plays b0 30 b30 :=
  Plays.snoc p29 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p31 : Plays b0 31 b31 :=
  Plays.snoc p30 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p32 : Plays b0 32 b32 :=
  Plays.snoc p31 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p33 : Plays b0 33 b33 :=
  Plays.snoc p32 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p34 : Plays b0 34 b34 :=
  Plays.snoc p33 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p35 : Plays b0 35 b35 :=
  Plays.snoc p34 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p36 : Plays b0 36 b36 :=
  Plays.snoc p35 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p37 : Plays b0 37 b37 :=
  Plays.snoc p36 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p38 : Plays b0 38 b38 :=
  Plays.snoc p37 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p39 : Plays b0 39 b39 :=
  Plays.snoc p38 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p40 : Plays b0 40 b40 :=
  Plays.snoc p39 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p41 : Plays b0 41 b41 :=
  Plays.snoc p40 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p42 : Plays b0 42 b42 :=
  Plays.snoc p41 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p43 : Plays b0 43 b43 :=
  Plays.snoc p42 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p44 : Plays b0 44 b44 :=
  Plays.snoc p43 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p45 : Plays b0 45 b45 :=
  Plays.snoc p44 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p46 : Plays b0 46 b46 :=
  Plays.snoc p45 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p47 : Plays b0 47 b47 :=
  Plays.snoc p46 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p48 : Plays b0 48 b48 :=
  Plays.snoc p47 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p49 : Plays b0 49 b49 :=
  Plays.snoc p48 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p50 : Plays b0 50 b50 :=
  Plays.snoc p49 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p51 : Plays b0 51 b51 :=
  Plays.snoc p50 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p52 : Plays b0 52 b52 :=
  Plays.snoc p51 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p53 : Plays b0 53 b53 :=
  Plays.snoc p52 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p54 : Plays b0 54 b54 :=
  Plays.snoc p53 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p55 : Plays b0 55 b55 :=
  Plays.snoc p54 ⟨.down, .i1, .i2, 4⟩ (by decide +kernel)
theorem p56 : Plays b0 56 b56 :=
  Plays.snoc p55 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p57 : Plays b0 57 b57 :=
  Plays.snoc p56 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p58 : Plays b0 58 b58 :=
  Plays.snoc p57 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p59 : Plays b0 59 b59 :=
  Plays.snoc p58 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p60 : Plays b0 60 b60 :=
  Plays.snoc p59 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p61 : Plays b0 61 b61 :=
  Plays.snoc p60 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p62 : Plays b0 62 b62 :=
  Plays.snoc p61 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p63 : Plays b0 63 b63 :=
  Plays.snoc p62 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p64 : Plays b0 64 b64 :=
  Plays.snoc p63 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p65 : Plays b0 65 b65 :=
  Plays.snoc p64 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p66 : Plays b0 66 b66 :=
  Plays.snoc p65 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p67 : Plays b0 67 b67 :=
  Plays.snoc p66 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p68 : Plays b0 68 b68 :=
  Plays.snoc p67 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p69 : Plays b0 69 b69 :=
  Plays.snoc p68 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p70 : Plays b0 70 b70 :=
  Plays.snoc p69 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p71 : Plays b0 71 b71 :=
  Plays.snoc p70 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p72 : Plays b0 72 b72 :=
  Plays.snoc p71 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p73 : Plays b0 73 b73 :=
  Plays.snoc p72 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p74 : Plays b0 74 b74 :=
  Plays.snoc p73 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p75 : Plays b0 75 b75 :=
  Plays.snoc p74 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p76 : Plays b0 76 b76 :=
  Plays.snoc p75 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p77 : Plays b0 77 b77 :=
  Plays.snoc p76 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p78 : Plays b0 78 b78 :=
  Plays.snoc p77 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p79 : Plays b0 79 b79 :=
  Plays.snoc p78 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p80 : Plays b0 80 b80 :=
  Plays.snoc p79 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p81 : Plays b0 81 b81 :=
  Plays.snoc p80 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p82 : Plays b0 82 b82 :=
  Plays.snoc p81 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p83 : Plays b0 83 b83 :=
  Plays.snoc p82 ⟨.down, .i0, .i1, 4⟩ (by decide +kernel)
theorem p84 : Plays b0 84 b84 :=
  Plays.snoc p83 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p85 : Plays b0 85 b85 :=
  Plays.snoc p84 ⟨.right, .i0, .i2, 4⟩ (by decide +kernel)
theorem p86 : Plays b0 86 b86 :=
  Plays.snoc p85 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p87 : Plays b0 87 b87 :=
  Plays.snoc p86 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p88 : Plays b0 88 b88 :=
  Plays.snoc p87 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p89 : Plays b0 89 b89 :=
  Plays.snoc p88 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p90 : Plays b0 90 b90 :=
  Plays.snoc p89 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p91 : Plays b0 91 b91 :=
  Plays.snoc p90 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p92 : Plays b0 92 b92 :=
  Plays.snoc p91 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p93 : Plays b0 93 b93 :=
  Plays.snoc p92 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p94 : Plays b0 94 b94 :=
  Plays.snoc p93 ⟨.right, .i1, .i1, 4⟩ (by decide +kernel)
theorem p95 : Plays b0 95 b95 :=
  Plays.snoc p94 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p96 : Plays b0 96 b96 :=
  Plays.snoc p95 ⟨.left, .i0, .i3, 4⟩ (by decide +kernel)
theorem p97 : Plays b0 97 b97 :=
  Plays.snoc p96 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p98 : Plays b0 98 b98 :=
  Plays.snoc p97 ⟨.down, .i1, .i0, 4⟩ (by decide +kernel)
theorem p99 : Plays b0 99 b99 :=
  Plays.snoc p98 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p100 : Plays b0 100 b100 :=
  Plays.snoc p99 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p101 : Plays b0 101 b101 :=
  Plays.snoc p100 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p102 : Plays b0 102 b102 :=
  Plays.snoc p101 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p103 : Plays b0 103 b103 :=
  Plays.snoc p102 ⟨.left, .i0, .i2, 4⟩ (by decide +kernel)
theorem p104 : Plays b0 104 b104 :=
  Plays.snoc p103 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p105 : Plays b0 105 b105 :=
  Plays.snoc p104 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p106 : Plays b0 106 b106 :=
  Plays.snoc p105 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p107 : Plays b0 107 b107 :=
  Plays.snoc p106 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p108 : Plays b0 108 b108 :=
  Plays.snoc p107 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p109 : Plays b0 109 b109 :=
  Plays.snoc p108 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p110 : Plays b0 110 b110 :=
  Plays.snoc p109 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p111 : Plays b0 111 b111 :=
  Plays.snoc p110 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p112 : Plays b0 112 b112 :=
  Plays.snoc p111 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p113 : Plays b0 113 b113 :=
  Plays.snoc p112 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p114 : Plays b0 114 b114 :=
  Plays.snoc p113 ⟨.left, .i2, .i3, 4⟩ (by decide +kernel)
theorem p115 : Plays b0 115 b115 :=
  Plays.snoc p114 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p116 : Plays b0 116 b116 :=
  Plays.snoc p115 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p117 : Plays b0 117 b117 :=
  Plays.snoc p116 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p118 : Plays b0 118 b118 :=
  Plays.snoc p117 ⟨.left, .i1, .i3, 4⟩ (by decide +kernel)
theorem p119 : Plays b0 119 b119 :=
  Plays.snoc p118 ⟨.down, .i1, .i3, 4⟩ (by decide +kernel)
theorem p120 : Plays b0 120 b120 :=
  Plays.snoc p119 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p121 : Plays b0 121 b121 :=
  Plays.snoc p120 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p122 : Plays b0 122 b122 :=
  Plays.snoc p121 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p123 : Plays b0 123 b123 :=
  Plays.snoc p122 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p124 : Plays b0 124 b124 :=
  Plays.snoc p123 ⟨.right, .i0, .i2, 4⟩ (by decide +kernel)
theorem p125 : Plays b0 125 b125 :=
  Plays.snoc p124 ⟨.down, .i0, .i3, 4⟩ (by decide +kernel)
theorem p126 : Plays b0 126 b126 :=
  Plays.snoc p125 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p127 : Plays b0 127 b127 :=
  Plays.snoc p126 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
theorem p128 : Plays b0 128 b128 :=
  Plays.snoc p127 ⟨.right, .i0, .i1, 4⟩ (by decide +kernel)
end Segment0143
theorem chunk0143 : Plays c0143 128 c0144 :=
  Segment0143.p128

end Game2048.Cert131072
