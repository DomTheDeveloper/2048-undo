import Game2048.Generated.Checkpoints

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace Game2048.Cert131072

namespace Segment0256
def b0 : Board := c0256
def b1 : Board := ⟨⟨16,8,8,2⟩,⟨32,64,128,256⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b2 : Board := c0257
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i3, 2⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.left, .i0, .i3, 2⟩ (by decide +kernel)
end Segment0256
theorem chunk0256 : Plays c0256 2 c0257 :=
  Segment0256.p2

namespace Segment0257
def b0 : Board := c0257
def b1 : Board := ⟨⟨32,4,2,0⟩,⟨32,64,128,256⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b2 : Board := ⟨⟨2,4,2,0⟩,⟨64,64,128,256⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b3 : Board := ⟨⟨0,2,4,2⟩,⟨4,128,128,256⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b4 : Board := ⟨⟨0,2,4,2⟩,⟨4,4,256,256⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b5 : Board := ⟨⟨4,2,4,2⟩,⟨0,0,8,512⟩,⟨4096,2048,1024,512⟩,⟨8192,16384,32768,65536⟩⟩
def b6 : Board := ⟨⟨2,0,4,0⟩,⟨4,2,8,2⟩,⟨4096,2048,1024,1024⟩,⟨8192,16384,32768,65536⟩⟩
def b7 : Board := ⟨⟨4,0,2,4⟩,⟨4,2,8,2⟩,⟨0,4096,2048,2048⟩,⟨8192,16384,32768,65536⟩⟩
def b8 : Board := ⟨⟨2,4,2,4⟩,⟨4,2,8,2⟩,⟨0,0,4096,4096⟩,⟨8192,16384,32768,65536⟩⟩
def b9 : Board := ⟨⟨2,4,2,4⟩,⟨4,2,8,2⟩,⟨8192,0,4,0⟩,⟨8192,16384,32768,65536⟩⟩
def b10 : Board := ⟨⟨4,0,2,0⟩,⟨2,4,8,4⟩,⟨4,2,4,2⟩,⟨16384,16384,32768,65536⟩⟩
def b11 : Board := ⟨⟨2,0,4,2⟩,⟨2,4,8,4⟩,⟨4,2,4,2⟩,⟨0,32768,32768,65536⟩⟩
def b12 : Board := ⟨⟨4,2,4,2⟩,⟨2,4,8,4⟩,⟨4,2,4,2⟩,⟨0,0,65536,65536⟩⟩
def b13 : Board := c0258
theorem p0 : Plays b0 0 b0 := Plays.refl
theorem p1 : Plays b0 1 b1 :=
  Plays.snoc p0 ⟨.left, .i0, .i2, 2⟩ (by decide +kernel)
theorem p2 : Plays b0 2 b2 :=
  Plays.snoc p1 ⟨.down, .i0, .i0, 2⟩ (by decide +kernel)
theorem p3 : Plays b0 3 b3 :=
  Plays.snoc p2 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p4 : Plays b0 4 b4 :=
  Plays.snoc p3 ⟨.right, .i1, .i0, 4⟩ (by decide +kernel)
theorem p5 : Plays b0 5 b5 :=
  Plays.snoc p4 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p6 : Plays b0 6 b6 :=
  Plays.snoc p5 ⟨.down, .i0, .i0, 2⟩ (by decide +kernel)
theorem p7 : Plays b0 7 b7 :=
  Plays.snoc p6 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p8 : Plays b0 8 b8 :=
  Plays.snoc p7 ⟨.right, .i0, .i0, 2⟩ (by decide +kernel)
theorem p9 : Plays b0 9 b9 :=
  Plays.snoc p8 ⟨.left, .i2, .i2, 4⟩ (by decide +kernel)
theorem p10 : Plays b0 10 b10 :=
  Plays.snoc p9 ⟨.down, .i0, .i0, 4⟩ (by decide +kernel)
theorem p11 : Plays b0 11 b11 :=
  Plays.snoc p10 ⟨.right, .i0, .i0, 2⟩ (by decide +kernel)
theorem p12 : Plays b0 12 b12 :=
  Plays.snoc p11 ⟨.right, .i0, .i0, 4⟩ (by decide +kernel)
theorem p13 : Plays b0 13 b13 :=
  Plays.snoc p12 ⟨.right, .i3, .i0, 2⟩ (by decide +kernel)
end Segment0257
theorem chunk0257 : Plays c0257 13 c0258 :=
  Segment0257.p13

end Game2048.Cert131072
