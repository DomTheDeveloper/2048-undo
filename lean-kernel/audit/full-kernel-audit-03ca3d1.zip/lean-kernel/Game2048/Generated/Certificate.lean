import Game2048.Generated.Block000
import Game2048.Generated.Block001
import Game2048.Generated.Block002
import Game2048.Generated.Block003
import Game2048.Generated.Block004
import Game2048.Generated.Block005
import Game2048.Generated.Block006
import Game2048.Generated.Block007
import Game2048.Generated.Block008
import Game2048.Generated.Block009
import Game2048.Generated.Block010
import Game2048.Generated.Block011
import Game2048.Generated.Block012
import Game2048.Generated.Block013
import Game2048.Generated.Block014
import Game2048.Generated.Block015
import Game2048.Generated.Block016

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace Game2048.Cert131072

theorem prefix0000 : Plays c0000 0 c0000 := Plays.refl
theorem prefix0001 : Plays c0000 128 c0001 :=
  Plays.append prefix0000 chunk0000
theorem prefix0002 : Plays c0000 256 c0002 :=
  Plays.append prefix0001 chunk0001
theorem prefix0003 : Plays c0000 384 c0003 :=
  Plays.append prefix0002 chunk0002
theorem prefix0004 : Plays c0000 512 c0004 :=
  Plays.append prefix0003 chunk0003
theorem prefix0005 : Plays c0000 640 c0005 :=
  Plays.append prefix0004 chunk0004
theorem prefix0006 : Plays c0000 768 c0006 :=
  Plays.append prefix0005 chunk0005
theorem prefix0007 : Plays c0000 896 c0007 :=
  Plays.append prefix0006 chunk0006
theorem prefix0008 : Plays c0000 1024 c0008 :=
  Plays.append prefix0007 chunk0007
theorem prefix0009 : Plays c0000 1152 c0009 :=
  Plays.append prefix0008 chunk0008
theorem prefix0010 : Plays c0000 1280 c0010 :=
  Plays.append prefix0009 chunk0009
theorem prefix0011 : Plays c0000 1408 c0011 :=
  Plays.append prefix0010 chunk0010
theorem prefix0012 : Plays c0000 1536 c0012 :=
  Plays.append prefix0011 chunk0011
theorem prefix0013 : Plays c0000 1664 c0013 :=
  Plays.append prefix0012 chunk0012
theorem prefix0014 : Plays c0000 1792 c0014 :=
  Plays.append prefix0013 chunk0013
theorem prefix0015 : Plays c0000 1920 c0015 :=
  Plays.append prefix0014 chunk0014
theorem prefix0016 : Plays c0000 2048 c0016 :=
  Plays.append prefix0015 chunk0015
theorem prefix0017 : Plays c0000 2176 c0017 :=
  Plays.append prefix0016 chunk0016
theorem prefix0018 : Plays c0000 2304 c0018 :=
  Plays.append prefix0017 chunk0017
theorem prefix0019 : Plays c0000 2432 c0019 :=
  Plays.append prefix0018 chunk0018
theorem prefix0020 : Plays c0000 2560 c0020 :=
  Plays.append prefix0019 chunk0019
theorem prefix0021 : Plays c0000 2688 c0021 :=
  Plays.append prefix0020 chunk0020
theorem prefix0022 : Plays c0000 2816 c0022 :=
  Plays.append prefix0021 chunk0021
theorem prefix0023 : Plays c0000 2944 c0023 :=
  Plays.append prefix0022 chunk0022
theorem prefix0024 : Plays c0000 3072 c0024 :=
  Plays.append prefix0023 chunk0023
theorem prefix0025 : Plays c0000 3200 c0025 :=
  Plays.append prefix0024 chunk0024
theorem prefix0026 : Plays c0000 3328 c0026 :=
  Plays.append prefix0025 chunk0025
theorem prefix0027 : Plays c0000 3456 c0027 :=
  Plays.append prefix0026 chunk0026
theorem prefix0028 : Plays c0000 3584 c0028 :=
  Plays.append prefix0027 chunk0027
theorem prefix0029 : Plays c0000 3712 c0029 :=
  Plays.append prefix0028 chunk0028
theorem prefix0030 : Plays c0000 3840 c0030 :=
  Plays.append prefix0029 chunk0029
theorem prefix0031 : Plays c0000 3968 c0031 :=
  Plays.append prefix0030 chunk0030
theorem prefix0032 : Plays c0000 4096 c0032 :=
  Plays.append prefix0031 chunk0031
theorem prefix0033 : Plays c0000 4224 c0033 :=
  Plays.append prefix0032 chunk0032
theorem prefix0034 : Plays c0000 4352 c0034 :=
  Plays.append prefix0033 chunk0033
theorem prefix0035 : Plays c0000 4480 c0035 :=
  Plays.append prefix0034 chunk0034
theorem prefix0036 : Plays c0000 4608 c0036 :=
  Plays.append prefix0035 chunk0035
theorem prefix0037 : Plays c0000 4736 c0037 :=
  Plays.append prefix0036 chunk0036
theorem prefix0038 : Plays c0000 4864 c0038 :=
  Plays.append prefix0037 chunk0037
theorem prefix0039 : Plays c0000 4992 c0039 :=
  Plays.append prefix0038 chunk0038
theorem prefix0040 : Plays c0000 5120 c0040 :=
  Plays.append prefix0039 chunk0039
theorem prefix0041 : Plays c0000 5248 c0041 :=
  Plays.append prefix0040 chunk0040
theorem prefix0042 : Plays c0000 5376 c0042 :=
  Plays.append prefix0041 chunk0041
theorem prefix0043 : Plays c0000 5504 c0043 :=
  Plays.append prefix0042 chunk0042
theorem prefix0044 : Plays c0000 5632 c0044 :=
  Plays.append prefix0043 chunk0043
theorem prefix0045 : Plays c0000 5760 c0045 :=
  Plays.append prefix0044 chunk0044
theorem prefix0046 : Plays c0000 5888 c0046 :=
  Plays.append prefix0045 chunk0045
theorem prefix0047 : Plays c0000 6016 c0047 :=
  Plays.append prefix0046 chunk0046
theorem prefix0048 : Plays c0000 6144 c0048 :=
  Plays.append prefix0047 chunk0047
theorem prefix0049 : Plays c0000 6272 c0049 :=
  Plays.append prefix0048 chunk0048
theorem prefix0050 : Plays c0000 6400 c0050 :=
  Plays.append prefix0049 chunk0049
theorem prefix0051 : Plays c0000 6528 c0051 :=
  Plays.append prefix0050 chunk0050
theorem prefix0052 : Plays c0000 6656 c0052 :=
  Plays.append prefix0051 chunk0051
theorem prefix0053 : Plays c0000 6784 c0053 :=
  Plays.append prefix0052 chunk0052
theorem prefix0054 : Plays c0000 6912 c0054 :=
  Plays.append prefix0053 chunk0053
theorem prefix0055 : Plays c0000 7040 c0055 :=
  Plays.append prefix0054 chunk0054
theorem prefix0056 : Plays c0000 7168 c0056 :=
  Plays.append prefix0055 chunk0055
theorem prefix0057 : Plays c0000 7296 c0057 :=
  Plays.append prefix0056 chunk0056
theorem prefix0058 : Plays c0000 7424 c0058 :=
  Plays.append prefix0057 chunk0057
theorem prefix0059 : Plays c0000 7552 c0059 :=
  Plays.append prefix0058 chunk0058
theorem prefix0060 : Plays c0000 7680 c0060 :=
  Plays.append prefix0059 chunk0059
theorem prefix0061 : Plays c0000 7808 c0061 :=
  Plays.append prefix0060 chunk0060
theorem prefix0062 : Plays c0000 7936 c0062 :=
  Plays.append prefix0061 chunk0061
theorem prefix0063 : Plays c0000 8064 c0063 :=
  Plays.append prefix0062 chunk0062
theorem prefix0064 : Plays c0000 8192 c0064 :=
  Plays.append prefix0063 chunk0063
theorem prefix0065 : Plays c0000 8320 c0065 :=
  Plays.append prefix0064 chunk0064
theorem prefix0066 : Plays c0000 8448 c0066 :=
  Plays.append prefix0065 chunk0065
theorem prefix0067 : Plays c0000 8576 c0067 :=
  Plays.append prefix0066 chunk0066
theorem prefix0068 : Plays c0000 8704 c0068 :=
  Plays.append prefix0067 chunk0067
theorem prefix0069 : Plays c0000 8832 c0069 :=
  Plays.append prefix0068 chunk0068
theorem prefix0070 : Plays c0000 8960 c0070 :=
  Plays.append prefix0069 chunk0069
theorem prefix0071 : Plays c0000 9088 c0071 :=
  Plays.append prefix0070 chunk0070
theorem prefix0072 : Plays c0000 9216 c0072 :=
  Plays.append prefix0071 chunk0071
theorem prefix0073 : Plays c0000 9344 c0073 :=
  Plays.append prefix0072 chunk0072
theorem prefix0074 : Plays c0000 9472 c0074 :=
  Plays.append prefix0073 chunk0073
theorem prefix0075 : Plays c0000 9600 c0075 :=
  Plays.append prefix0074 chunk0074
theorem prefix0076 : Plays c0000 9728 c0076 :=
  Plays.append prefix0075 chunk0075
theorem prefix0077 : Plays c0000 9856 c0077 :=
  Plays.append prefix0076 chunk0076
theorem prefix0078 : Plays c0000 9984 c0078 :=
  Plays.append prefix0077 chunk0077
theorem prefix0079 : Plays c0000 10112 c0079 :=
  Plays.append prefix0078 chunk0078
theorem prefix0080 : Plays c0000 10240 c0080 :=
  Plays.append prefix0079 chunk0079
theorem prefix0081 : Plays c0000 10368 c0081 :=
  Plays.append prefix0080 chunk0080
theorem prefix0082 : Plays c0000 10496 c0082 :=
  Plays.append prefix0081 chunk0081
theorem prefix0083 : Plays c0000 10624 c0083 :=
  Plays.append prefix0082 chunk0082
theorem prefix0084 : Plays c0000 10752 c0084 :=
  Plays.append prefix0083 chunk0083
theorem prefix0085 : Plays c0000 10880 c0085 :=
  Plays.append prefix0084 chunk0084
theorem prefix0086 : Plays c0000 11008 c0086 :=
  Plays.append prefix0085 chunk0085
theorem prefix0087 : Plays c0000 11136 c0087 :=
  Plays.append prefix0086 chunk0086
theorem prefix0088 : Plays c0000 11264 c0088 :=
  Plays.append prefix0087 chunk0087
theorem prefix0089 : Plays c0000 11392 c0089 :=
  Plays.append prefix0088 chunk0088
theorem prefix0090 : Plays c0000 11520 c0090 :=
  Plays.append prefix0089 chunk0089
theorem prefix0091 : Plays c0000 11648 c0091 :=
  Plays.append prefix0090 chunk0090
theorem prefix0092 : Plays c0000 11776 c0092 :=
  Plays.append prefix0091 chunk0091
theorem prefix0093 : Plays c0000 11904 c0093 :=
  Plays.append prefix0092 chunk0092
theorem prefix0094 : Plays c0000 12032 c0094 :=
  Plays.append prefix0093 chunk0093
theorem prefix0095 : Plays c0000 12160 c0095 :=
  Plays.append prefix0094 chunk0094
theorem prefix0096 : Plays c0000 12288 c0096 :=
  Plays.append prefix0095 chunk0095
theorem prefix0097 : Plays c0000 12416 c0097 :=
  Plays.append prefix0096 chunk0096
theorem prefix0098 : Plays c0000 12544 c0098 :=
  Plays.append prefix0097 chunk0097
theorem prefix0099 : Plays c0000 12672 c0099 :=
  Plays.append prefix0098 chunk0098
theorem prefix0100 : Plays c0000 12800 c0100 :=
  Plays.append prefix0099 chunk0099
theorem prefix0101 : Plays c0000 12928 c0101 :=
  Plays.append prefix0100 chunk0100
theorem prefix0102 : Plays c0000 13056 c0102 :=
  Plays.append prefix0101 chunk0101
theorem prefix0103 : Plays c0000 13184 c0103 :=
  Plays.append prefix0102 chunk0102
theorem prefix0104 : Plays c0000 13312 c0104 :=
  Plays.append prefix0103 chunk0103
theorem prefix0105 : Plays c0000 13440 c0105 :=
  Plays.append prefix0104 chunk0104
theorem prefix0106 : Plays c0000 13568 c0106 :=
  Plays.append prefix0105 chunk0105
theorem prefix0107 : Plays c0000 13696 c0107 :=
  Plays.append prefix0106 chunk0106
theorem prefix0108 : Plays c0000 13824 c0108 :=
  Plays.append prefix0107 chunk0107
theorem prefix0109 : Plays c0000 13952 c0109 :=
  Plays.append prefix0108 chunk0108
theorem prefix0110 : Plays c0000 14080 c0110 :=
  Plays.append prefix0109 chunk0109
theorem prefix0111 : Plays c0000 14208 c0111 :=
  Plays.append prefix0110 chunk0110
theorem prefix0112 : Plays c0000 14336 c0112 :=
  Plays.append prefix0111 chunk0111
theorem prefix0113 : Plays c0000 14464 c0113 :=
  Plays.append prefix0112 chunk0112
theorem prefix0114 : Plays c0000 14592 c0114 :=
  Plays.append prefix0113 chunk0113
theorem prefix0115 : Plays c0000 14720 c0115 :=
  Plays.append prefix0114 chunk0114
theorem prefix0116 : Plays c0000 14848 c0116 :=
  Plays.append prefix0115 chunk0115
theorem prefix0117 : Plays c0000 14976 c0117 :=
  Plays.append prefix0116 chunk0116
theorem prefix0118 : Plays c0000 15104 c0118 :=
  Plays.append prefix0117 chunk0117
theorem prefix0119 : Plays c0000 15232 c0119 :=
  Plays.append prefix0118 chunk0118
theorem prefix0120 : Plays c0000 15360 c0120 :=
  Plays.append prefix0119 chunk0119
theorem prefix0121 : Plays c0000 15488 c0121 :=
  Plays.append prefix0120 chunk0120
theorem prefix0122 : Plays c0000 15616 c0122 :=
  Plays.append prefix0121 chunk0121
theorem prefix0123 : Plays c0000 15744 c0123 :=
  Plays.append prefix0122 chunk0122
theorem prefix0124 : Plays c0000 15872 c0124 :=
  Plays.append prefix0123 chunk0123
theorem prefix0125 : Plays c0000 16000 c0125 :=
  Plays.append prefix0124 chunk0124
theorem prefix0126 : Plays c0000 16128 c0126 :=
  Plays.append prefix0125 chunk0125
theorem prefix0127 : Plays c0000 16256 c0127 :=
  Plays.append prefix0126 chunk0126
theorem prefix0128 : Plays c0000 16384 c0128 :=
  Plays.append prefix0127 chunk0127
theorem prefix0129 : Plays c0000 16512 c0129 :=
  Plays.append prefix0128 chunk0128
theorem prefix0130 : Plays c0000 16640 c0130 :=
  Plays.append prefix0129 chunk0129
theorem prefix0131 : Plays c0000 16768 c0131 :=
  Plays.append prefix0130 chunk0130
theorem prefix0132 : Plays c0000 16896 c0132 :=
  Plays.append prefix0131 chunk0131
theorem prefix0133 : Plays c0000 17024 c0133 :=
  Plays.append prefix0132 chunk0132
theorem prefix0134 : Plays c0000 17152 c0134 :=
  Plays.append prefix0133 chunk0133
theorem prefix0135 : Plays c0000 17280 c0135 :=
  Plays.append prefix0134 chunk0134
theorem prefix0136 : Plays c0000 17408 c0136 :=
  Plays.append prefix0135 chunk0135
theorem prefix0137 : Plays c0000 17536 c0137 :=
  Plays.append prefix0136 chunk0136
theorem prefix0138 : Plays c0000 17664 c0138 :=
  Plays.append prefix0137 chunk0137
theorem prefix0139 : Plays c0000 17792 c0139 :=
  Plays.append prefix0138 chunk0138
theorem prefix0140 : Plays c0000 17920 c0140 :=
  Plays.append prefix0139 chunk0139
theorem prefix0141 : Plays c0000 18048 c0141 :=
  Plays.append prefix0140 chunk0140
theorem prefix0142 : Plays c0000 18176 c0142 :=
  Plays.append prefix0141 chunk0141
theorem prefix0143 : Plays c0000 18304 c0143 :=
  Plays.append prefix0142 chunk0142
theorem prefix0144 : Plays c0000 18432 c0144 :=
  Plays.append prefix0143 chunk0143
theorem prefix0145 : Plays c0000 18560 c0145 :=
  Plays.append prefix0144 chunk0144
theorem prefix0146 : Plays c0000 18688 c0146 :=
  Plays.append prefix0145 chunk0145
theorem prefix0147 : Plays c0000 18816 c0147 :=
  Plays.append prefix0146 chunk0146
theorem prefix0148 : Plays c0000 18944 c0148 :=
  Plays.append prefix0147 chunk0147
theorem prefix0149 : Plays c0000 19072 c0149 :=
  Plays.append prefix0148 chunk0148
theorem prefix0150 : Plays c0000 19200 c0150 :=
  Plays.append prefix0149 chunk0149
theorem prefix0151 : Plays c0000 19328 c0151 :=
  Plays.append prefix0150 chunk0150
theorem prefix0152 : Plays c0000 19456 c0152 :=
  Plays.append prefix0151 chunk0151
theorem prefix0153 : Plays c0000 19584 c0153 :=
  Plays.append prefix0152 chunk0152
theorem prefix0154 : Plays c0000 19712 c0154 :=
  Plays.append prefix0153 chunk0153
theorem prefix0155 : Plays c0000 19840 c0155 :=
  Plays.append prefix0154 chunk0154
theorem prefix0156 : Plays c0000 19968 c0156 :=
  Plays.append prefix0155 chunk0155
theorem prefix0157 : Plays c0000 20096 c0157 :=
  Plays.append prefix0156 chunk0156
theorem prefix0158 : Plays c0000 20224 c0158 :=
  Plays.append prefix0157 chunk0157
theorem prefix0159 : Plays c0000 20352 c0159 :=
  Plays.append prefix0158 chunk0158
theorem prefix0160 : Plays c0000 20480 c0160 :=
  Plays.append prefix0159 chunk0159
theorem prefix0161 : Plays c0000 20608 c0161 :=
  Plays.append prefix0160 chunk0160
theorem prefix0162 : Plays c0000 20736 c0162 :=
  Plays.append prefix0161 chunk0161
theorem prefix0163 : Plays c0000 20864 c0163 :=
  Plays.append prefix0162 chunk0162
theorem prefix0164 : Plays c0000 20992 c0164 :=
  Plays.append prefix0163 chunk0163
theorem prefix0165 : Plays c0000 21120 c0165 :=
  Plays.append prefix0164 chunk0164
theorem prefix0166 : Plays c0000 21248 c0166 :=
  Plays.append prefix0165 chunk0165
theorem prefix0167 : Plays c0000 21376 c0167 :=
  Plays.append prefix0166 chunk0166
theorem prefix0168 : Plays c0000 21504 c0168 :=
  Plays.append prefix0167 chunk0167
theorem prefix0169 : Plays c0000 21632 c0169 :=
  Plays.append prefix0168 chunk0168
theorem prefix0170 : Plays c0000 21760 c0170 :=
  Plays.append prefix0169 chunk0169
theorem prefix0171 : Plays c0000 21888 c0171 :=
  Plays.append prefix0170 chunk0170
theorem prefix0172 : Plays c0000 22016 c0172 :=
  Plays.append prefix0171 chunk0171
theorem prefix0173 : Plays c0000 22144 c0173 :=
  Plays.append prefix0172 chunk0172
theorem prefix0174 : Plays c0000 22272 c0174 :=
  Plays.append prefix0173 chunk0173
theorem prefix0175 : Plays c0000 22400 c0175 :=
  Plays.append prefix0174 chunk0174
theorem prefix0176 : Plays c0000 22528 c0176 :=
  Plays.append prefix0175 chunk0175
theorem prefix0177 : Plays c0000 22656 c0177 :=
  Plays.append prefix0176 chunk0176
theorem prefix0178 : Plays c0000 22784 c0178 :=
  Plays.append prefix0177 chunk0177
theorem prefix0179 : Plays c0000 22912 c0179 :=
  Plays.append prefix0178 chunk0178
theorem prefix0180 : Plays c0000 23040 c0180 :=
  Plays.append prefix0179 chunk0179
theorem prefix0181 : Plays c0000 23168 c0181 :=
  Plays.append prefix0180 chunk0180
theorem prefix0182 : Plays c0000 23296 c0182 :=
  Plays.append prefix0181 chunk0181
theorem prefix0183 : Plays c0000 23424 c0183 :=
  Plays.append prefix0182 chunk0182
theorem prefix0184 : Plays c0000 23552 c0184 :=
  Plays.append prefix0183 chunk0183
theorem prefix0185 : Plays c0000 23680 c0185 :=
  Plays.append prefix0184 chunk0184
theorem prefix0186 : Plays c0000 23808 c0186 :=
  Plays.append prefix0185 chunk0185
theorem prefix0187 : Plays c0000 23936 c0187 :=
  Plays.append prefix0186 chunk0186
theorem prefix0188 : Plays c0000 24064 c0188 :=
  Plays.append prefix0187 chunk0187
theorem prefix0189 : Plays c0000 24192 c0189 :=
  Plays.append prefix0188 chunk0188
theorem prefix0190 : Plays c0000 24320 c0190 :=
  Plays.append prefix0189 chunk0189
theorem prefix0191 : Plays c0000 24448 c0191 :=
  Plays.append prefix0190 chunk0190
theorem prefix0192 : Plays c0000 24576 c0192 :=
  Plays.append prefix0191 chunk0191
theorem prefix0193 : Plays c0000 24704 c0193 :=
  Plays.append prefix0192 chunk0192
theorem prefix0194 : Plays c0000 24832 c0194 :=
  Plays.append prefix0193 chunk0193
theorem prefix0195 : Plays c0000 24960 c0195 :=
  Plays.append prefix0194 chunk0194
theorem prefix0196 : Plays c0000 25088 c0196 :=
  Plays.append prefix0195 chunk0195
theorem prefix0197 : Plays c0000 25216 c0197 :=
  Plays.append prefix0196 chunk0196
theorem prefix0198 : Plays c0000 25344 c0198 :=
  Plays.append prefix0197 chunk0197
theorem prefix0199 : Plays c0000 25472 c0199 :=
  Plays.append prefix0198 chunk0198
theorem prefix0200 : Plays c0000 25600 c0200 :=
  Plays.append prefix0199 chunk0199
theorem prefix0201 : Plays c0000 25728 c0201 :=
  Plays.append prefix0200 chunk0200
theorem prefix0202 : Plays c0000 25856 c0202 :=
  Plays.append prefix0201 chunk0201
theorem prefix0203 : Plays c0000 25984 c0203 :=
  Plays.append prefix0202 chunk0202
theorem prefix0204 : Plays c0000 26112 c0204 :=
  Plays.append prefix0203 chunk0203
theorem prefix0205 : Plays c0000 26240 c0205 :=
  Plays.append prefix0204 chunk0204
theorem prefix0206 : Plays c0000 26368 c0206 :=
  Plays.append prefix0205 chunk0205
theorem prefix0207 : Plays c0000 26496 c0207 :=
  Plays.append prefix0206 chunk0206
theorem prefix0208 : Plays c0000 26624 c0208 :=
  Plays.append prefix0207 chunk0207
theorem prefix0209 : Plays c0000 26752 c0209 :=
  Plays.append prefix0208 chunk0208
theorem prefix0210 : Plays c0000 26880 c0210 :=
  Plays.append prefix0209 chunk0209
theorem prefix0211 : Plays c0000 27008 c0211 :=
  Plays.append prefix0210 chunk0210
theorem prefix0212 : Plays c0000 27136 c0212 :=
  Plays.append prefix0211 chunk0211
theorem prefix0213 : Plays c0000 27264 c0213 :=
  Plays.append prefix0212 chunk0212
theorem prefix0214 : Plays c0000 27392 c0214 :=
  Plays.append prefix0213 chunk0213
theorem prefix0215 : Plays c0000 27520 c0215 :=
  Plays.append prefix0214 chunk0214
theorem prefix0216 : Plays c0000 27648 c0216 :=
  Plays.append prefix0215 chunk0215
theorem prefix0217 : Plays c0000 27776 c0217 :=
  Plays.append prefix0216 chunk0216
theorem prefix0218 : Plays c0000 27904 c0218 :=
  Plays.append prefix0217 chunk0217
theorem prefix0219 : Plays c0000 28032 c0219 :=
  Plays.append prefix0218 chunk0218
theorem prefix0220 : Plays c0000 28160 c0220 :=
  Plays.append prefix0219 chunk0219
theorem prefix0221 : Plays c0000 28288 c0221 :=
  Plays.append prefix0220 chunk0220
theorem prefix0222 : Plays c0000 28416 c0222 :=
  Plays.append prefix0221 chunk0221
theorem prefix0223 : Plays c0000 28544 c0223 :=
  Plays.append prefix0222 chunk0222
theorem prefix0224 : Plays c0000 28672 c0224 :=
  Plays.append prefix0223 chunk0223
theorem prefix0225 : Plays c0000 28800 c0225 :=
  Plays.append prefix0224 chunk0224
theorem prefix0226 : Plays c0000 28928 c0226 :=
  Plays.append prefix0225 chunk0225
theorem prefix0227 : Plays c0000 29056 c0227 :=
  Plays.append prefix0226 chunk0226
theorem prefix0228 : Plays c0000 29184 c0228 :=
  Plays.append prefix0227 chunk0227
theorem prefix0229 : Plays c0000 29312 c0229 :=
  Plays.append prefix0228 chunk0228
theorem prefix0230 : Plays c0000 29440 c0230 :=
  Plays.append prefix0229 chunk0229
theorem prefix0231 : Plays c0000 29568 c0231 :=
  Plays.append prefix0230 chunk0230
theorem prefix0232 : Plays c0000 29696 c0232 :=
  Plays.append prefix0231 chunk0231
theorem prefix0233 : Plays c0000 29824 c0233 :=
  Plays.append prefix0232 chunk0232
theorem prefix0234 : Plays c0000 29952 c0234 :=
  Plays.append prefix0233 chunk0233
theorem prefix0235 : Plays c0000 30080 c0235 :=
  Plays.append prefix0234 chunk0234
theorem prefix0236 : Plays c0000 30208 c0236 :=
  Plays.append prefix0235 chunk0235
theorem prefix0237 : Plays c0000 30336 c0237 :=
  Plays.append prefix0236 chunk0236
theorem prefix0238 : Plays c0000 30464 c0238 :=
  Plays.append prefix0237 chunk0237
theorem prefix0239 : Plays c0000 30592 c0239 :=
  Plays.append prefix0238 chunk0238
theorem prefix0240 : Plays c0000 30720 c0240 :=
  Plays.append prefix0239 chunk0239
theorem prefix0241 : Plays c0000 30848 c0241 :=
  Plays.append prefix0240 chunk0240
theorem prefix0242 : Plays c0000 30976 c0242 :=
  Plays.append prefix0241 chunk0241
theorem prefix0243 : Plays c0000 31104 c0243 :=
  Plays.append prefix0242 chunk0242
theorem prefix0244 : Plays c0000 31232 c0244 :=
  Plays.append prefix0243 chunk0243
theorem prefix0245 : Plays c0000 31360 c0245 :=
  Plays.append prefix0244 chunk0244
theorem prefix0246 : Plays c0000 31488 c0246 :=
  Plays.append prefix0245 chunk0245
theorem prefix0247 : Plays c0000 31616 c0247 :=
  Plays.append prefix0246 chunk0246
theorem prefix0248 : Plays c0000 31744 c0248 :=
  Plays.append prefix0247 chunk0247
theorem prefix0249 : Plays c0000 31872 c0249 :=
  Plays.append prefix0248 chunk0248
theorem prefix0250 : Plays c0000 32000 c0250 :=
  Plays.append prefix0249 chunk0249
theorem prefix0251 : Plays c0000 32128 c0251 :=
  Plays.append prefix0250 chunk0250
theorem prefix0252 : Plays c0000 32256 c0252 :=
  Plays.append prefix0251 chunk0251
theorem prefix0253 : Plays c0000 32384 c0253 :=
  Plays.append prefix0252 chunk0252
theorem prefix0254 : Plays c0000 32512 c0254 :=
  Plays.append prefix0253 chunk0253
theorem prefix0255 : Plays c0000 32640 c0255 :=
  Plays.append prefix0254 chunk0254
theorem prefix0256 : Plays c0000 32766 c0256 :=
  Plays.append prefix0255 chunk0255
theorem prefix0257 : Plays c0000 32768 c0257 :=
  Plays.append prefix0256 chunk0256
theorem prefix0258 : Plays c0000 32781 c0258 :=
  Plays.append prefix0257 chunk0257

def initial : Board := c0000
def terminal : Board := c0258
def primed : Board := c0256

theorem start_valid : IsInitial initial := by
  refine ⟨.i3, .i2, .i3, .i3, 4, 4, ?_, ?_, ?_, ?_⟩
  all_goals decide +kernel

theorem certified_play : Plays initial 32781 terminal :=
  prefix0258

theorem certified_primed_prefix : Plays initial 32766 primed :=
  prefix0256

theorem contains_terminal : terminal.Contains 131072 := by
  exact ⟨.i3, .i3, by decide +kernel⟩

#print axioms certified_play
end Game2048.Cert131072
